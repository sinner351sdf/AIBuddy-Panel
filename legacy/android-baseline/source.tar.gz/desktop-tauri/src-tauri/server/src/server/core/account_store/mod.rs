//! 账号存储（对照 Node 版 src/workbuddy-account-store.mjs 全量移植）。
//!
//! ── 持久化：SQLite `accounts` 表（本切片从 accounts.json 迁过来）────
//! 数据落在 `{config_dir}/agent2api.db` 的 `accounts` 表里（表结构见
//! `server/db/schema.rs`）。每条记录一行，`data` 列存**整条账号记录的 JSON
//! 原文**（下面不变量 1 的实现方式），另有 `id` / `provider` / `priority` /
//! `enabled` / `added_at` 五列是从 JSON 派生的**查询投影**（排序/筛选/唯一性
//! 校验用），派生规则与读写粒度见 `sql.rs` 的模块头。
//! 记录形状不变，仍是：
//!   `[{ id, provider, name, uid, nickname, type, enterpriseId,
//!     enterpriseName, accessToken, refreshToken, expiresAt, refreshExpiresAt,
//!     domain, tokenTail, prefixPath, endpoint, platform, edition, addedAt,
//!     updatedAt, priority, enabled, proxy, rateLimits: { [modelId]: {...} } }]`
//!
//! ── 三条不变量（改代码前务必读）──────────────────────────────
//!   1. **未知字段全量保留**：账号记录用强类型字段 + `extra` 兜底，写回时合并。
//!      用户升级时绝不能丢账号里的任何字段（旧版遗留的 currentAccountId、
//!      手工加的备注、未来版本新增的字段都在这条兜底里）。
//!      新增的 `provider` 是**已知字段**，同样不许在重建记录时丢掉。
//!      数据库形态下这条落在 `data` 列的「整条 JSON 原文」上。
//!   2. **优先级全局唯一**（所有提供商共用一条队列）：数值小的先用（主备式）。
//!      写入侧冲突一律拒绝（409），启动时对既有数据做一次性迁移
//!      （`migrate_startup`：旧版按家分队的号码按旧顺序合并成全局队列 + 去重）。
//!      **分组模式（账号页按家分组）再加一条：同一家的账号在队列里连续** ——
//!      组的顺位由「该家最靠前的账号」决定，界面上「第 N 顺位的家排在前面」这句
//!      话才与真实尝试顺序一致。维护它只需两处：新增/导入一律落在本组末尾
//!      （`sql::put` 里的那一跳），整队拖拽由 `store_order::reorder_accounts`
//!      按用户拖出来的顺序重编号。规则本身在 `priority::grouped_queue_order`。
//!      「当前账号」不是独立存储的手动选择，而是**由优先级派生** ——
//!      全局队列里第一个「已启用且有可用凭证」的账号（`pick_current`），所以不存在
//!      「手动选了 A、实际用 B」这种分叉。想换当前账号就把目标置顶。
//!      桌面端实时账号同样算「有凭证」。逐家的队首仍在快照的 `currentAccountIds`
//!      里给出（只有参考意义）。
//!   3. **provider 字段的兜底口径**：加载时缺失/为空一律补 `"workbuddy"`
//!      （历史数据都来自单上游时代），由 `migrate_startup` 与优先级去重
//!      同机一次落盘完成（架构文档 §3.2）。未知 provider 字符串**原样保留** ——
//!      可能是新版本写入的数据被旧版本读到，强行归一会让账号跑进错误的组。
//!
//! ── provider 白名单：没有第二份清单（W4a 明确）─────────────────
//! 本模块**不维护** `["workbuddy","raccoon"]` 这样的 id 清单，将来也不要加：
//! 「这个 provider id 认不认识」一律走
//! `providers::is_known_provider_id`（= `kind_from_id(id).is_some()`，
//! 事实来源是 `providers::PROVIDERS` 注册表）。于是「加一家 provider」只改
//! 注册表一处，账号层（添加/分支/校验/摘要）零改动 —— W4a 加 CatPaw / AutoClaw
//! 时正是这么做的。各家**专属**的行为（小浣熊的公开字段集、桌面端实时凭证、
//! 添加与导入路径）仍按 id 判定，那属于「这一家的特殊实现」而非白名单。
//!
//! ── 并发模型 ──────────────────────────────────────────────
//! Node 版是单线程事件循环；这里整个 store 用一把 `std::sync::Mutex` 串行化
//! 整个「读-改-写」周期，锁粒度不精细但语义等价。它保护的**不是文件**了：
//! 以前是「整份文件读-改-写」，现在是「数据库上的一次读改写周期」——账号层的
//! 「读一条 → 在 Rust 里改 → 写回」跨了多条语句，SQLite 的事务管不到这段
//! （"改"发生在 Rust 内存里），所以这把锁仍然必需（详见 `store.rs` 的说明）。
//! 硬约束：**持锁期间绝不做网络请求**（会阻塞所有管理 API）—— 需要出网的调用
//! （token 刷新、积分查询）一律先在锁内取出快照，释放锁后再发请求，回头再
//! 单独写回。
//!
//! 子模块分工（对照 Node 版的单文件拆分）：
//!   priority.rs  优先级号段规则（归一/排序/找号/整队，按 provider 分组使用）
//!   state.rs     记录结构（JSON 原样持有 + 容错访问器 + 磁盘形态 + provider 分组工具）
//!   sql.rs       行级 SQL 访问层：一行 ↔ StoredAccount 的编解码、按需查询、
//!                单行增删改与整份状态的差异写入（本模块唯一出现 SQL 的文件）
//!   store_util.rs JS 语义工具（`x || y` / `Number(x)` / `JSON.stringify` 比较…）
//!   store.rs     AccountStore 句柄：打开/锁/连接、装载与保存、当前账号派生、
//!                按 id / provider 的按需读取
//!   store_view.rs 公开形态（各家形状分派 + 跨家事实注入）、列表快照、provider 摘要
//!   store_crud.rs 增删改查（add/remove/promote/update/move 与 apply_patch 内核）
//!   store_order.rs 队列顺序（分组模式）：按给定顺序整队重编号（`reorder_accounts`）
//!   store_batch.rs 批量操作（batch_update / batch_remove）
//!   store_admin.rs token 回写、限额标记、启动迁移（provider 补齐 + 优先级去重）
//!   raccoon_accounts.rs 小浣熊账号（W3-T4）：手动添加、桌面端实时账号、
//!                刷新回写、小浣熊公开形态
//!   raccoon_import.rs   小浣熊旧数据一次性导入（旧网关 accounts.json +
//!                桌面端登录态；架构文档 §3.3）
//!   catpaw_accounts.rs  CatPaw 账号（W5-T-d4）：手动添加（扁平/auth.json/
//!                原项目账号记录三种形态）、桌面端实时账号、CatPaw 公开形态
//!   catpaw_import.rs    CatPaw 旧数据一次性导入（原项目 catpaw-proxy-accounts.json
//!                + ~/.meituan-catpaw/auth.json；§9）
//!   autoclaw_accounts.rs AutoClaw 账号（W4b-T-c2）：手动添加（扁平/auth.json 内容
//!                两种形态，enc: 密文自动解密）、桌面端实时账号、刷新回写、
//!                AutoClaw 公开形态（userId / deviceId / tokenTail）
//!   autoclaw_import.rs   AutoClaw 旧数据一次性导入（~/.autoclaw-proxy/accounts.json
//!                + 桌面端登录态；§10.2）
//!   cline_accounts.rs    Cline 账号（两个额度池）：手动添加、桌面端登录态、
//!                续期回写、Cline 公开形态
//!   qoder_accounts.rs    Qoder 账号（地区 + userId 识别）：添加、凭证刷新回写、
//!                Qoder 公开形态
//!   custom_accounts.rs   自定义提供商账号（`custom-` 前缀的 provider）：手动
//!                添加（apiKey + baseUrl 覆盖项）、级联删除、custom 公开形态；
//!                存储与校验的架构说明见 `core::custom_providers`
//!   accio_accounts.rs    Accio 账号（两个地区各一家 provider）：添加（粘贴凭证 /
//!                网页登录共用入口）、续期回写、公开形态（含 edition）
//!   monkeycode_accounts.rs MonkeyCode 账号（两个站点各一家 provider）：粘贴
//!                session 添加（session + imageId + userId）、公开形态（含 edition）
//!   commandcode_accounts.rs Command Code 账号（单一 provider）：粘贴 `user_`
//!                开头的 API Key 添加、公开形态（只给尾号）
//!   antigravity_accounts.rs Antigravity 账号（单一 provider）：粘贴 Google
//!                refresh token 添加、刷新回写（比较-再写）、公开形态（只给尾号）

pub mod accio_accounts;
pub mod antigravity_accounts;
pub mod autoclaw_accounts;
pub mod autoclaw_import;
pub mod catpaw_accounts;
pub mod catpaw_import;
pub mod chatglm_accounts;
pub mod cline_accounts;
pub mod codearts_accounts;
pub mod commandcode_accounts;
pub mod custom_accounts;
pub mod kuku_accounts;
pub mod loomy_accounts;
pub mod monkeycode_accounts;
pub mod officeace_accounts;
pub mod orcaterm_accounts;
pub mod priority;
pub mod qoder_accounts;
pub mod raccoon_accounts;
pub mod raccoon_import;
pub mod sql;
pub mod state;
pub mod store;
pub mod store_admin;
pub mod store_batch;
pub mod store_crud;
pub mod store_order;
pub mod store_util;
pub mod store_view;
pub mod trae_accounts;
pub mod workbuddy_import;
pub mod zcode_accounts;

pub use store::{AccountStore, AccountStoreError};

/// 凭证回写的结果（**比较-再写**的返回值，刷新链路专用）。
///
/// 刷新是秒级的网络动作，期间凭证可能被换掉（用户重导入、换号、桌面端重新
/// 登录、另一轮刷新先落地）。回写方法因此不接受「无条件覆盖」：调用方给出
/// **刷新前那份凭证**，store 在**同一把账号锁内**比较后再写。判定不一致时返回
/// [`CredentialWrite::Stale`] —— 调用方必须改用最新快照，绝不能把旧结果当成功
/// 用于后续请求。
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum CredentialWrite {
    /// 已写入（记录里仍是刷新前那份凭证）
    Written,
    /// 未写入：记录里的凭证已被更换（或账号已被删除 / 同 id 重建），刷新结果作废
    Stale,
}

/// token 长度上限（对照 Node 版 MAX_TOKEN_LENGTH）
pub const MAX_TOKEN_LENGTH: usize = 8192;

/// CatPaw provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`RACCOON_PROVIDER_ID`] 的口径 —— 注册表改了 id，这个常量跟着变）。
pub(crate) const CATPAW_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::CatPaw,
);

/// AutoClaw provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`RACCOON_PROVIDER_ID`] 的口径）。
///
/// 这是**国内版**的 id（历史值，不改名 —— 存量账号的落盘契约）；
/// 国际版见 [`AUTOCLAW_INTL_PROVIDER_ID`]。判「是不是 AutoClaw 系」用
/// [`is_autoclaw_family`]。
pub(crate) const AUTOCLAW_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::AutoClaw,
);

/// AutoClaw **国际版** provider id（同 [`AUTOCLAW_PROVIDER_ID`] 的口径）。
///
/// 两个地区是两家 provider（理由见 `providers::autoclaw::region` 的模块头）：
/// 各有独立的账号集合，因此账号层的「按家过滤」必须区分它们 ——
/// 而「公开形态 / 身份字段」这类两地同形的判定用 [`is_autoclaw_family`]。
pub(crate) const AUTOCLAW_INTL_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::AutoClawIntl,
);

/// Qoder provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`RACCOON_PROVIDER_ID`] 的口径）。Qoder 的账号形态与推理转发见
/// `qoder_accounts.rs` 与 `providers::qoder` 的模块头。
/// Trae provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`RACCOON_PROVIDER_ID`] 的口径）。账号形态见 `trae_accounts.rs`。
pub(crate) const TRAE_PROVIDER_ID: &str =
    crate::server::core::providers::kind_id(crate::server::core::providers::ProviderKind::Trae);

/// Loomy（讯飞）provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`TRAE_PROVIDER_ID`] 的口径）。账号形态见 `loomy_accounts.rs`。
pub(crate) const LOOMY_PROVIDER_ID: &str =
    crate::server::core::providers::kind_id(crate::server::core::providers::ProviderKind::Loomy);

/// MonkeyCode **国内版** provider id（账号存储内部多处要用；**从注册表推导**）。
/// 账号形态见 `monkeycode_accounts.rs`；判「是不是 MonkeyCode 系」用
/// [`is_monkeycode_family`]。
pub(crate) const MONKEYCODE_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::MonkeyCode,
);

/// MonkeyCode **国际版** provider id（同 [`MONKEYCODE_PROVIDER_ID`] 的口径）。
///
/// 两个站点是两家 provider（理由见 `providers::monkeycode::region` 的模块头）：
/// 各有独立的账号集合，账号层的「按家过滤」必须区分它们。
pub(crate) const MONKEYCODE_INTL_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::MonkeyCodeIntl,
);

/// 这个 provider 是不是 **MonkeyCode 系**（两个站点之一）。
///
/// 与 [`is_accio_family`] / [`is_zcode_family`] 同一形态、同一理由：账号层有
/// 几处判断只关心「是不是 MonkeyCode」，不关心哪个站点。
pub(crate) fn is_monkeycode_family(provider_id: &str) -> bool {
    provider_id == MONKEYCODE_PROVIDER_ID || provider_id == MONKEYCODE_INTL_PROVIDER_ID
}

/// Command Code provider id（账号存储内部多处要用；**从注册表推导**）。
/// 账号形态见 `commandcode_accounts.rs`（单一 provider、没有地区之分）。
pub(crate) const COMMANDCODE_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::CommandCode,
);

/// Antigravity provider id（账号存储内部多处要用；**从注册表推导**）。
/// 账号形态见 `antigravity_accounts.rs`（单一 provider、没有地区之分 ——
/// `sandbox`/`daily`/`prod` 是环境不是地区，规格 §6）。
pub(crate) const ANTIGRAVITY_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::Antigravity,
);

/// OfficeAce（华为云果办 / OfficeClaw）provider id（**从注册表推导**，同
/// [`LOOMY_PROVIDER_ID`] 的口径）。账号形态见 `officeace_accounts.rs`。
pub(crate) const OFFICEACE_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::OfficeAce,
);

/// Cline **免费池** provider id（账号存储内部多处要用；**从注册表推导**，同
/// [`RACCOON_PROVIDER_ID`] 的口径）。账号形态见 `cline_accounts.rs`。
pub(crate) const CLINE_FREE_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::ClineFree,
);

/// Cline **订阅池** provider id（同 [`CLINE_FREE_PROVIDER_ID`] 的口径）
pub(crate) const CLINE_PASS_PROVIDER_ID: &str = crate::server::core::providers::kind_id(
    crate::server::core::providers::ProviderKind::ClinePass,
);

/// 这个 provider 是不是 **Cline 系**（两个额度池之一）。
///
/// 账号层几处判断只关心「是不是 Cline」（桌面端实时凭据、余额、续期回写、
/// 身份字段落在 `account` 键上），不关心哪个池 —— 那些分支全走本函数，
/// 于是将来加池或改名时只需改这里一处，而不是散在各文件里的 `id == "cline"`。
///
/// 注意 `"cline"` 这个 id **已经不存在**（拆分后是 `cline-free` /
/// `cline-pass`，见 `providers::PROVIDERS`）：写 `id == "cline"` 会恒为假，
/// 是个不会报错的静默失配，所以这里给出唯一的判据函数。
pub(crate) fn is_cline_family(provider_id: &str) -> bool {
    provider_id == CLINE_FREE_PROVIDER_ID || provider_id == CLINE_PASS_PROVIDER_ID
}

/// 这个 provider 是不是 **AutoClaw 系**（两个地区之一）。
///
/// 与 [`is_cline_family`] 同一形态、同一理由：账号层有几处判断只关心
/// 「是不是 AutoClaw」（公开形态、身份字段落在 `userId` 上），不关心哪个地区 ——
/// 那些分支走本函数，于是加地区或改名时只改这里一处，而不是散在各文件里的
/// `id == "autoclaw"`（那种写法对国际版恒为假，是个不会报错的静默失配）。
pub(crate) fn is_autoclaw_family(provider_id: &str) -> bool {
    provider_id == AUTOCLAW_PROVIDER_ID || provider_id == AUTOCLAW_INTL_PROVIDER_ID
}

/// 这个 provider 是不是 **Accio 系**（两个地区之一）。
///
/// 与 [`is_autoclaw_family`] 同一形态、同一理由：账号层有几处判断只关心
/// 「是不是 Accio」（签到范围排除、公开形态），不关心哪个地区 ——
/// 那些分支走本函数，于是加地区或改名时只改这里一处，而不是散在各文件里的
/// `id == "accio"`（那种写法对国内版恒为假，是个不会报错的静默失配）。
pub(crate) fn is_accio_family(provider_id: &str) -> bool {
    crate::server::core::providers::accio::endpoints::Region::from_provider_id(provider_id).is_some()
}

/// 这个 provider 是不是 **ZCode 系**（两个地区之一）。
///
/// 与 [`is_autoclaw_family`] / [`is_accio_family`] 同一形态、同一理由：
/// 账号层有几处判断只关心「是不是 ZCode」（签到范围排除、公开形态、
/// 领取任务的账号枚举），不关心哪个地区 —— 那些分支走本函数，于是加地区
/// 或改名时只改这里一处，而不是散在各文件里的 `id == "zcode"`
/// （那种写法对国际版恒为假，是个不会报错的静默失配）。
pub(crate) fn is_zcode_family(provider_id: &str) -> bool {
    crate::server::core::providers::zcode::region::Region::from_provider_id(provider_id).is_some()
}

/// 这个 provider 是不是 **Qoder 系**（`qoder` 中国版 / `qoder-intl` 国际版）。
///
/// 与 [`is_accio_family`] / [`is_zcode_family`] 同一形态、同一理由：账号层有
/// 几处判断只关心「是不是 Qoder」（公开形态、身份字段），不关心哪个地区 ——
/// 那些分支走本函数，于是加地区或改名时只改这里一处，而不是散在各文件里的
/// `id == "qoder"`（那种写法对国际版恒为假，是个不会报错的静默失配）。
pub(crate) fn is_qoder_family(provider_id: &str) -> bool {
    crate::server::core::providers::qoder::endpoints::Region::from_provider_id(provider_id)
        .is_some()
}

/// 小浣熊 provider id（账号存储内部多处要用）。
///
/// **从注册表推导**（W4a）：`providers::kind_id` 是 `const fn`，所以这里可以
/// `const` 声明而不再写第二份字面量 —— 注册表改了 id，这个常量跟着变，
/// 不会出现「账号存储按 `"raccoon"` 找、注册表里叫别的」这种静默失配。
///
/// ── 账号层的 provider 白名单在哪（W4a 的口径）─────────────────
/// 本模块**没有**一份 `["workbuddy", "raccoon"]` 式的清单，也刻意不再加：
/// 「这个 provider id 认不认识」一律走
/// `providers::is_known_provider_id`（= `kind_from_id(id).is_some()`，事实来源是
/// `providers::PROVIDERS` 注册表），需要**枚举**全部 id 时直接遍历那张表。
/// 于是以后加 provider（CatPaw / AutoClaw 已加）只改注册表，账号层零改动。
///
/// 各家**专属**的分支（小浣熊的公开字段集、桌面端实时凭证、添加/导入路径）
/// 仍然按 id 判定 —— 那是「这一家的特殊行为」，不是白名单，改动量随新家到来
/// 天然增加（每一家都有自己的一套字段与凭证链路）。
pub(crate) const RACCOON_PROVIDER_ID: &str =
    crate::server::core::providers::kind_id(
        crate::server::core::providers::ProviderKind::Raccoon,
    );
