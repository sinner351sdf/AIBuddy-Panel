//! 无头登录（device-flow 风格）与登录任务表。
//!
//! 流程与桌面端 createSession 完全一致（对照 src/workbuddy-auth.mjs 的
//! `loginInteractive`，以及 server.mjs 614-668 行的 startLoginTask /
//! cancelLoginTask / loginTasks）：
//!
//!   ① POST {endpoint}/v2{prefix}/auth/state?platform=workbuddy   （匿名）
//!        → data.authUrl + data.state
//!   ② 用户在浏览器打开 authUrl 完成登录
//!   ③ 每 3 秒 GET {endpoint}/v2{prefix}/auth/token?state=<state> （匿名）
//!        → data.accessToken / refreshToken / expiresIn / refreshExpiresIn
//!        未完成时上游返回 code=11217，需继续轮询
//!   ④ GET {endpoint}/v2{prefix}/login/account?state=<state>     （Bearer）
//!        → 账号详情（失败不影响登录，回退用 ⑤ 的列表）
//!   ⑤ GET {endpoint}/v2{prefix}/accounts                        （Bearer）
//!        → data.accounts[]
//!
//! 登录成功后把会话交给账号存储入库（Node 版 `accountStore.addAccount(session)`）。
//!
//! ── 任务表与取消 ──────────────────────────────────────────
//! 每次登录是一个 `LoginTask`（`Arc<Mutex<...>>`），`/start` 拿到句柄后最多等
//! 15 秒的 authUrl，拿到就把任务按 state 登记进表供 `/wait` 查询；拿不到就回
//! 502（任务本身继续在后台跑，与 Node 版一致）。
//!
//! 取消不走 AbortController 而是置任务上的 `canceled` 标记 —— 轮询循环每一拍
//! 检查一次，语义等价（Node 的 signal.aborted 也是循环里检查）。
//! 任务完成后保留 10 分钟，清理在「取任务时顺手做过期检查」里完成，
//! 不额外起后台定时器。

mod accio;
mod autoclaw;
mod catpaw;
pub mod codearts;
mod qoder;
mod officeace;
mod trae;
mod zcode;

use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Duration;

use serde_json::{json, Value};

use crate::server::core::account_store::AccountStore;
use crate::server::core::auth::{
    anonymous_headers, context_for_edition, send_public_request, unwrap_public_response, urlencoding,
    with_expires_at, AuthService, WorkBuddyAuthError, SERVER_CODE_RETRY_FETCH_TOKEN,
};
use crate::server::core::endpoints::{resolve_edition, Context, DEFAULT_EDITION};
use crate::server::core::providers::workbuddy::Region;
use crate::server::core::providers::adapter::adapter_for;
use crate::server::core::providers::raccoon::oauth;
use crate::server::core::providers::{kind_from_id, kind_id, ProviderKind};
use crate::server::errors::GatewayError;
use crate::server::logging;

/// 登录轮询间隔与总超时（桌面端 SIGN_IN_FETCH_INTERVAL / SIGN_IN_PENDING_TIMEOUT）
pub const LOGIN_POLL_INTERVAL_MS: u64 = 3000;
pub const LOGIN_TIMEOUT_MS: u64 = 5 * 60 * 1000;
/// `/start` 等 authUrl 的上限（对应 server.mjs 的 `Date.now() + 15000`）
pub const AUTH_URL_WAIT_MS: u64 = 15_000;
/// 任务完成后在表里保留 10 分钟（Node 版 setTimeout 同值）
const TASK_RETENTION_MS: i64 = 10 * 60 * 1000;

/// 一次登录任务的状态（对应 Node 版 `loginTasks` 里的 task 对象）。
#[derive(Clone, Debug, Default)]
pub struct LoginTaskState {
    pub state: Option<String>,
    pub auth_url: Option<String>,
    pub done: bool,
    pub error: Option<String>,
    /// 成功后的会话摘要 `{ accountUid, nickname, edition }`
    pub session: Option<Value>,
    pub edition: String,
    /// 这次登录属于哪一家（provider id）。
    ///
    /// 为什么必须记在任务上：`/wait` 只按 state 查任务，而**回调换凭证**那一步
    /// （`submit_login_callback`）必须知道该调哪家的 `exchange_login_code`。
    /// 换凭证是网络动作，不能靠调用方再传一次 provider —— 那等于让客户端
    /// 决定「用哪家的协议解释这个 state」，把一条内部契约暴露成入参。
    ///
    /// 缺省（default）为空串，`new_handle_for_provider` 会写上一家；
    /// 空串在回调侧按「不认识」拒绝，不会静默落到某一家。
    pub provider: String,
    pub canceled: bool,
    pub phase: String,
    pub expires_at: i64,
    finished_at: Option<i64>,
}

impl LoginTaskState {
    /// `/api/session/login/wait` 的三分支响应：
    /// `{pending:true}` / `{done:true,error}` / `{done:true,session}`
    pub fn to_wait_response(&self) -> Value {
        if !self.done {
            return json!({ "pending": true, "phase":self.phase,"expiresAt":self.expires_at });
        }
        if let Some(error) = &self.error {
            return json!({ "done": true, "error": error,"phase":"error","errorKind":if error.contains("超时"){"expired"}else if error.contains("保存"){"save_failed"}else{"network"} });
        }
        json!({ "done": true, "phase":"success", "session": self.session.clone().unwrap_or(Value::Null) })
    }
}

/// 任务句柄：登录流程与 `/start`、`/wait`、`/cancel` 共享同一个状态。
#[derive(Clone)]
pub struct LoginTaskHandle {
    inner: Arc<Mutex<LoginTaskState>>,
    /// 唯一标识（表里按 state 索引，未拿到 state 前用它做日志与查找兜底）
    ticket: u64,
}

/// 手工提交网页登录回调后的结果。
///
/// CodeArts 的第一跳只有 `secret`，必须先把浏览器送回 portal 才能拿到最终
/// `code`；远程网页端不能依赖 public callback 路由替它跳转，因此把下一跳地址
/// 显式交回受保护接口的调用方。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum LoginCallbackSubmission {
    Completed(String),
    ContinueTo(String),
}

impl LoginTaskHandle {
    fn lock(&self) -> MutexGuard<'_, LoginTaskState> {
        match self.inner.lock() {
            Ok(guard) => guard,
            Err(poisoned) => poisoned.into_inner(),
        }
    }

    pub fn snapshot(&self) -> LoginTaskState {
        self.lock().clone()
    }

    fn update(&self, action: impl FnOnce(&mut LoginTaskState)) {
        let mut guard = self.lock();
        action(&mut guard);
    }

    pub fn ticket(&self) -> u64 {
        self.ticket
    }
}

/// 登录任务表：`state → 任务`。
///
/// 只登记「已拿到 state」的任务 —— 与 Node 版一致（它在 onAuthUrl 回调里
/// 才 `loginTasks.set(state, task)`），所以拿不到 authUrl 的失败任务不会
/// 被 `/wait` 查到，前端会收到 404「登录任务不存在或已过期」。
#[derive(Clone)]
pub struct LoginTasks {
    inner: Arc<Mutex<TaskTable>>,
}

struct TaskTable {
    by_state: HashMap<String, LoginTaskHandle>,
    next_ticket: u64,
}

impl LoginTasks {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(TaskTable { by_state: HashMap::new(), next_ticket: 1 })),
        }
    }

    fn lock(&self) -> MutexGuard<'_, TaskTable> {
        match self.inner.lock() {
            Ok(guard) => guard,
            Err(poisoned) => poisoned.into_inner(),
        }
    }

    /// 清理过期任务（完成后 10 分钟）。取任务时顺手做，不起后台定时器 ——
    /// 桌面端关掉弹窗后不会再有 /wait 轮询，此时残留的任务对象也只是几十字节，
    /// 下次任何一次取任务都会把它扫掉。
    fn sweep(table: &mut TaskTable) {
        let now = logging::now_ms();
        table.by_state.retain(|_, handle| match handle.lock().finished_at {
            Some(finished) => now - finished < TASK_RETENTION_MS,
            None => true,
        });
    }

    pub fn get(&self, state: &str) -> Option<LoginTaskHandle> {
        if state.is_empty() {
            return None;
        }
        let mut table = self.lock();
        Self::sweep(&mut table);
        table.by_state.get(state).cloned()
    }

    /// 登记任务（`/start` 拿到 state 后调用）
    pub fn register(&self, state: &str, handle: LoginTaskHandle) -> bool {
        if state.is_empty() {
            return false;
        }
        let mut table = self.lock();
        Self::sweep(&mut table);
        table.by_state.insert(state.to_string(), handle);
        true
    }

    /// 取消任务：置 canceled 标记（轮询循环下一拍退出）并**立即从表里移除**。
    ///
    /// 移除是刻意的：Node 版 `cancelLoginTask` 同样 `loginTasks.delete(state)`，
    /// 于是前端紧接着的那次 `/wait` 会拿到 404「登录任务不存在或已过期」——
    /// 壳侧 login.rs 正是靠这条文案判定「用户已放弃」，直接结束等待循环
    /// （见其 `error.contains("登录任务不存在")` 分支）。保留任务反而会让
    /// 那次 /wait 拿到一个 error 字符串，走进「打印错误继续轮询」的分支。
    ///
    /// 返回是否真的取消了。已结束/不存在的任务返回 false。
    pub fn cancel(&self, state: &str) -> bool {
        let Some(handle) = self.get(state) else {
            return false;
        };
        {
            let mut task = handle.lock();
            if task.done || task.phase=="saved" {
                return false;
            }
            task.canceled = true;
            task.done = true;
            task.error = Some("登录已取消".to_string());
            task.finished_at = Some(logging::now_ms());
        }
        {
            let mut table = self.lock();
            // 按 state 或按句柄（state 未入表时用 ticket 兜底，两者必居其一）
            let ticket = handle.ticket();
            table
                .by_state
                .retain(|_, item| item.ticket() != ticket);
        }
        logging::log("[Login]", "登录任务已取消（用户放弃等待）");
        true
    }

    /// 占位一个任务号（`/start` 与任务句柄共用，仅用于诊断日志）
    fn next_ticket(table: &mut TaskTable) -> u64 {
        let ticket = table.next_ticket;
        table.next_ticket = table.next_ticket.wrapping_add(1);
        ticket
    }
}

impl Default for LoginTasks {
    fn default() -> Self {
        Self::new()
    }
}

/// 登录服务：把 auth（会话与账号接口）与任务表绑在一起。
#[derive(Clone)]
pub struct LoginService {
    auth: AuthService,
    store: AccountStore,
    tasks: LoginTasks,
    /// AutoClaw OAuth 登录的额外状态（`state → PendingOauth`）。
    ///
    /// ── 为什么要单独一张表（不能塞进 LoginTaskState）────────────
    /// 那个结构是所有 provider 共用的、`/wait` 直接序列化它，往里加
    /// AutoClaw 专属字段会让每次 `/wait` 都多带一份别人用不到的负载，
    /// 也让「哪些字段是这家独有的」从类型上看不出来。见
    /// `login/autoclaw.rs` 的 `PendingOauth`。
    ///
    /// 生命周期与任务表一致（收尾时清掉）；进程重启后自然为空，那时回调
    /// 会被 `finish_autoclaw_oauth_callback` 判成「登录上下文已丢失」。
    autoclaw_oauth: Arc<Mutex<HashMap<String, autoclaw::PendingOauth>>>,
    /// Trae 网页登录的额外状态（`state → 进行中的一轮`）。
    ///
    /// 单独一张表而不是塞进 `LoginTaskState`（同 [`Self::autoclaw_oauth`] 的理由）：
    /// 它的值是**活对象**（持有本机回调监听器），既不能序列化给 `/wait`，
    /// 也不该让别的 provider 每次轮询都陪着带一份别人用不到的东西。
    /// 表里同一时刻最多一条（见 `login/trae.rs` 模块头）。
    trae_login: Arc<Mutex<HashMap<String, Arc<crate::server::core::providers::trae::login::Session>>>>,
}

impl LoginService {
    pub fn new(auth: AuthService, store: AccountStore) -> Self {
        Self {
            auth,
            store,
            tasks: LoginTasks::new(),
            autoclaw_oauth: Arc::new(Mutex::new(HashMap::new())),
            trae_login: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub fn tasks(&self) -> &LoginTasks {
        &self.tasks
    }

    /// Trae 登录的待办表（`login/trae.rs` 用它挂这一轮的回调监听器）。
    pub(crate) fn trae_login(&self) -> &Arc<Mutex<HashMap<String, Arc<crate::server::core::providers::trae::login::Session>>>> {
        &self.trae_login
    }

    /// 取消一次登录：任务表那一步见 [`LoginTasks::cancel`]，这里多做的事是
    /// **把 AutoClaw 那条链的待办状态一起清掉**。
    ///
    /// ── 为什么必须在这一层清（不能只在 `LoginTasks::cancel` 里）────
    /// 那张表（`autoclaw_oauth`）是 `LoginService` 的字段，任务表看不见它。
    /// 而它**持有着**这一轮借来的回调端口（见 `login/autoclaw.rs` 的
    /// `PendingOauth::_listener`）：不清就要一直占到 5 分钟超时才还回去 ——
    /// 用户取消后往往立刻重试，那一次会因为「端口还被自己占着」而抢不到登记
    /// 端口（Zai 就会回落成走不通的形态）。其它家在这张表里没有条目，这一步
    /// 对它们是空操作。
    ///
    /// 锁序与 `start` 一致（先任务表、后待办表），且两个临界区不重叠。
    pub fn cancel(&self, state: &str) -> bool {
        let canceled = self.tasks.cancel(state);
        if canceled {
            self.autoclaw_oauth
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .remove(state);
            // CodeArts 那一轮的 PKCE verifier / DPoP 私钥在自己的待办表里，
            // 不清就要占到 5 分钟超时才还 —— 而用户取消后往往立刻重试。
            self.drop_codearts_pending(state);
            // Trae 这一家的待办表按 state 存，但取消语义是"这一轮不要了"：
            // 本家同时只有一轮，直接整体收摊（close 释放回调端口，正在等回调的
            // 后台任务随之退出）。不这么做就要把端口占到 5 分钟超时才还 ——
            // 与 AutoClaw 那次「取消后立刻重试抢不到端口」是同一个坑。
            if state.starts_with("trae-") {
                self.close_trae_login();
            }
        }
        canceled
    }

    /// 发起一次登录任务（对应 server.mjs 的 `startLoginTask`）。
    ///
    /// 立刻返回任务句柄，登录流程在后台任务里跑 —— authUrl 与 state 由
    /// 回调写进句柄，调用方（`/api/session/login/start`）负责等它出现。
    /// `region` 由**调用方按 provider id 反查**给出（国内版 / 国际版）。
    ///
    /// 拆家后不读 body 里的 `edition`：界面上两个地区是两个条目，点哪个就发
    /// 哪个 provider id —— 那是权威。拿一个回显字段定地区，会出现「点了国际版
    /// 却落了国内版账号」，而账号一旦落错家，转发会稳定打错域名
    /// （与 `api::session` 里 ZCode 那段注释同一条理由）。
    pub fn start(&self, region: Region) -> LoginTaskHandle {
        let handle = self.new_handle_for_provider(region.edition(), region.provider_id());
        self.spawn_login(handle.clone(), region);
        handle
    }

    /// 建一个任务句柄但不启动后台任务（`/auth/login` 的同步登录用它 ——
    /// 那条路径自己 await 登录流程，不能再起一个后台任务重复登录）
    fn new_handle(&self, region: Region) -> LoginTaskHandle {
        self.new_handle_for_provider(region.edition(), region.provider_id())
    }

    /// 同上，但显式指定 provider（网页登录的任务表要记住它，见 `LoginTaskState::provider`）。
    fn new_handle_for_provider(
        &self,
        info: &'static crate::server::core::endpoints::EditionInfo,
        provider: &str,
    ) -> LoginTaskHandle {
        let ticket = {
            let mut guard = self.tasks.lock();
            LoginTasks::next_ticket(&mut guard)
        };
        LoginTaskHandle {
            inner: Arc::new(Mutex::new(LoginTaskState {
                state: None,
                auth_url: None,
                done: false,
                error: None,
                session: None,
                edition: info.id.to_string(),
                provider: provider.to_string(),
                canceled: false,
                phase: "requesting".into(),
                expires_at: logging::now_ms()+LOGIN_TIMEOUT_MS as i64,
                finished_at: None,
            })),
            ticket,
        }
    }

    /// 发起一次「网页登录」任务（trait 扩展 7 的入口，小浣熊走这条）。
    ///
    /// 与 [`Self::start`] 的区别：这条**不碰上游** —— authUrl 与 state 都由
    /// provider 适配器自己拼（小浣熊的授权页地址是静态的，state 本地生成），
    /// 拿到回调里的 code 之前没有任何网络动作。因此没有后台任务、没有轮询，
    /// 任务句柄登记进表后等着 `submit_login_callback` 来收尾（或等 `cancel`）。
    ///
    /// 返回 `Err(原因)` 表示这家不支持网页登录（调用方据此报 400，文案原样透出）。
    pub fn start_web_login(&self, kind: ProviderKind) -> Result<LoginTaskHandle, String> {
        let label = crate::server::core::providers::meta(kind).label;
        let adapter = adapter_for(kind);
        // 先问能力再问地址：两个方法各有分工（`supports_web_login` 是恒定能力，
        // `build_login_url` 是这次的地址）。分开问才能把「这家没有这条协议」
        // 与「这家有协议但这次拼不出地址」在日志和文案里区分开。
        if !adapter.supports_web_login() {
            return Err(format!(
                "{label}不支持网页登录，请改用「填写凭证」或「导入桌面端登录态」添加账号"
            ));
        }
        // Fail before creating a login task or sending the user to Google.
        if kind_id(kind) == "antigravity" {
            crate::server::core::providers::antigravity::endpoints::oauth_client()
                .map_err(|error| error.message)?;
        }
        let Some((auth_url, state)) = adapter.build_login_url() else {
            return Err(format!("{label}未能生成网页登录授权地址，请重试"));
        };
        let info = resolve_edition(Some(DEFAULT_EDITION));
        let handle = self.new_handle_for_provider(info, kind_id(kind));
        handle.update(|task| {
            task.state = Some(state.clone());
            task.auth_url = Some(auth_url);
        });
        self.tasks.register(&state, handle.clone());
        logging::log("[Login]", &format!("发起{label}网页登录（等待浏览器回调…）"));
        Ok(handle)
    }

    /// KukuAI 网页登录收尾：校验任务 → 从登录态 Cookie 提取凭证 → 落账号。
    ///
    /// ── 与其它网页登录回调的差别（为什么单独一个入口）────────────
    /// 百度通行证登录成功后的跳转**不携带授权码**（凭证在 `.baidu.com` 域的
    /// Cookie 里，跨域跳转不会带过去），因此无法走「回调 URL 里解析 code」的
    /// 通用链路。本家由壳侧登录窗口的注入脚本把 Cookie 直接 POST 到
    /// `POST /api/session/login/kuku/complete`，这里完成「任务校验 → 提取 →
    /// 落账号 → 写任务状态」四步。任务状态的写回与 raccoon 分支同款
    /// （`finish_task`），前端 `/wait` 轮询拿到的结果与其它家一致。
    pub async fn finish_kuku_login(
        &self,
        state: &str,
        cookie: &str,
    ) -> Result<String, GatewayError> {
        let state = state.trim();
        if state.is_empty() {
            return Err(GatewayError::with_status(400, "缺少 state，无法确认这次回调归属"));
        }
        let Some(handle) = self.tasks.get(state) else {
            return Err(GatewayError::with_status(
                404,
                "登录任务不存在或已过期，请重新发起网页登录",
            ));
        };
        let task = handle.snapshot();
        if task.canceled {
            return Err(GatewayError::with_status(400, "登录已取消，请重新发起"));
        }
        if task.done {
            // 幂等：同一个回调被送来两次（脚本重入 + 页面重载各触发一次）不是错误
            return Ok(String::new());
        }
        if task.provider != crate::server::core::providers::kind_id(crate::server::core::providers::ProviderKind::Kuku) {
            return Err(GatewayError::with_status(
                400,
                "该登录任务不属于 KukuAI，请重新发起",
            ));
        }
        let (credentials, warning) =
            crate::server::core::providers::kuku::login::complete_login(cookie).await?;
        let store = self.store.clone();
        let account = store
            .add_kuku_account(&credentials, None, "web")
            .map_err(|error| GatewayError::with_status(error.status_code, error.message))?;
        let account_id = account
            .get("id")
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_string();
        let label = account
            .get("name")
            .and_then(Value::as_str)
            .unwrap_or("KukuAI 账号")
            .to_string();
        let mut payload = json!({ "account": account, "edition": task.edition });
        // 复核未通过的警告随任务载荷透传前端（账号已落库；提示换正确账号）
        if let Some(warning) = warning {
            payload["warning"] = Value::String(warning);
        }
        finish_task(&handle, &payload);
        logging::log("[Login]", &format!("✅ KukuAI 网页登录成功: {label}"));
        Ok(account_id)
    }

    /// OrcaTerm 网页登录收尾（**兜底入口**）：校验任务 → 归一化令牌 → 上游
    /// 探活 → 落账号。
    ///
    /// ── 现在的正式链路不在这里 ──────────────────────────────────
    /// 网页登录走**官方 OAuth**：回调 `orcaterm://oauth_callback?session_id=…`
    /// → `submit_login_callback` 的 OrcaTerm 分支 → `exchange_login_code`
    /// （见 `providers/orcaterm/login.rs` 模块头）。本方法是**第二条**收尾路径：
    /// 调用方手里已经有一枚现成令牌（壳侧若哪天从窗口里读到、或外部工具替我们
    /// 拿到了），直接 POST `{state, token}` 到
    /// `/api/session/login/orcaterm/complete` 即可 —— 两条路都落到同一套
    /// 「探活通过才落库」的口径上，不重复实现校验。
    ///
    /// ── 与 KukuAI 收尾的同与异 ──────────────────────────────────
    /// 同：都由壳侧进程 POST 进来，任务校验、幂等、写回 `/wait` 的时序一致
    /// （见 `finish_kuku_login`）。
    /// 异：这家的令牌必须**当场通过上游探活**才落库（`complete_login` 里打
    /// `GetUserInfo`）—— 过期/被撤销的令牌落下来只会得到必然 401 的账号；
    /// KukuAI 那条是「凭证本身有效、业务令牌换发另说」，所以它带警告照样落。
    ///
    /// 探活失败**不写任务终态**：令牌可能只是刚到手、上游尚未生效，调用方
    /// 可以再试；真正的错误文案由返回的 `Err` 透出去，最终由 `/wait` 超时兜底。
    pub async fn finish_orcaterm_login(
        &self,
        state: &str,
        token: &str,
    ) -> Result<String, GatewayError> {
        let state = state.trim();
        if state.is_empty() {
            return Err(GatewayError::with_status(400, "缺少 state，无法确认这次回调归属"));
        }
        let Some(handle) = self.tasks.get(state) else {
            return Err(GatewayError::with_status(
                404,
                "登录任务不存在或已过期，请重新发起网页登录",
            ));
        };
        let task = handle.snapshot();
        if task.canceled {
            return Err(GatewayError::with_status(400, "登录已取消，请重新发起"));
        }
        if task.done {
            // 幂等：同一个登录态被送来两次不是错误
            return Ok(String::new());
        }
        if task.provider != crate::server::core::providers::kind_id(crate::server::core::providers::ProviderKind::OrcaTerm)
        {
            return Err(GatewayError::with_status(
                400,
                "该登录任务不属于 OrcaTerm，请重新发起",
            ));
        }
        let credentials = match crate::server::core::providers::orcaterm::login::complete_login(token).await
        {
            Ok(credentials) => credentials,
            Err(error) => {
                // 失败也写门户日志：这条路径的错误以前只回给调用方，界面与日志面板
                // 都看不到（本轮排查「扫码后没反应」时正缺这条线索）。
                logging::log(
                    "[Login]",
                    &format!("❌ OrcaTerm 登录态校验失败: {}", error.message),
                );
                return Err(error);
            }
        };
        let store = self.store.clone();
        let account = store
            .add_orcaterm_account(&credentials, None, "web")
            .map_err(|error| GatewayError::with_status(error.status_code, error.message))?;
        let account_id = account
            .get("id")
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_string();
        let label = account
            .get("name")
            .and_then(Value::as_str)
            .unwrap_or("OrcaTerm 账号")
            .to_string();
        finish_task(&handle, &json!({ "account": account, "edition": task.edition }));
        logging::log("[Login]", &format!("✅ OrcaTerm 网页登录成功: {label}"));
        Ok(account_id)
    }

    /// 发起一次 **Cline 设备授权登录**（WorkOS RFC 8628）。
    ///
    /// ── 与前两条链路的区别（为什么是第三种形态）─────────────────
    ///   - `start`（workbuddy）：起后台任务问上游要 state/authUrl，**上游推**
    ///     authUrl 过来；
    ///   - `start_web_login`（小浣熊）：本地拼授权地址，等**浏览器回调**带 code；
    ///   - 本方法（Cline）：**同步问上游要 user_code 与授权页地址**（一次
    ///     POST），然后把地址回给界面；用户确认后由后台任务**轮询**换令牌。
    ///
    /// 三种形态的共同点是「前端只认 `{state, authUrl}` 这两个键」，因此对界面
    /// 而言它们是同一个东西：给一个 URL 去打开、等 `/wait` 返回结果。
    /// Cline 的 `authUrl` 用上游给的 `verification_uri_complete`（已带 user_code，
    /// 用户点开就免手输），`state` 用设备授权返回的 `deviceCode` 指纹 ——
    /// 它既是任务的表键，也是轮询时认这一轮的凭据。
    ///
    /// ── 后台任务为什么必须有 ────────────────────────────────────
    /// 用户确认是在浏览器里发生的，网关这边只能轮询。所以拿完 user_code 就要
    /// 起任务去轮询（`poll_and_register` 会一直等到确认 / 超时 / 取消），
    /// 结果写回任务句柄，前端照 `/wait` 的既有协议取。
    ///
    /// ── `provider` 传什么 ───────────────────────────────────────
    /// `"cline-free"` / `"cline-pass"` —— 登录落账号时进哪一家。
    /// **登录流程本身与池无关**（只有 api.cline.bot 一台站点、一套设备授权），
    /// 池只决定落的账号记录属于哪家、能广告哪批模型。
    pub async fn start_cline_device_login(
        &self,
        provider: &str,
        name: Option<String>,
    ) -> Result<LoginTaskHandle, String> {
        let label = crate::server::core::providers::label_of(provider);
        // 第一步要拿 user_code：这一步是同步等待的（一次 POST，30 秒超时在
        // `cline::login` 里），因为它决定 authUrl —— 拿不到就没有页面可给用户开。
        let start = crate::server::core::providers::cline::login::start()
            .await
            .map_err(|error| error.message)?;
        // state 用 device_code 的前缀：够稳定（同一轮设备授权唯一）、够短
        // （进表键与日志），且不把完整的 device_code 暴露到界面上
        let state = format!(
            "cline-{}",
            crate::server::core::account_store::store_util::truncate_text(&start.device_code, 12)
        );
        let auth_url = start
            .verification_uri_complete
            .clone()
            .unwrap_or_else(|| start.verification_uri.clone());
        let info = resolve_edition(Some(DEFAULT_EDITION));
        let handle = self.new_handle_for_provider(info, provider);
        handle.update(|task| {
            task.state = Some(state.clone());
            task.auth_url = Some(auth_url.clone());
        });
        self.tasks.register(&state, handle.clone());
        logging::log(
            "[Login]",
            &format!("发起{label}设备授权登录（授权码 {}）", start.user_code),
        );
        // 后台轮询：用户确认后换令牌、落账号、写回句柄
        let service = self.clone();
        let task_state = state.clone();
        let task_provider = provider.to_string();
        tokio::spawn(async move {
            let store = service.store.clone();
            let result = crate::server::core::providers::cline::login::poll_and_register(
                &store,
                &start,
                &task_provider,
                name.as_deref(),
            )
            .await;
            let Some(handle) = service.tasks.get(&task_state) else {
                // 任务已被 cancel / 过期回收：结果无处可写（账号已经落地，
                // 用户下次刷新列表就能看到 —— 这里只记一条日志）
                logging::verbose(
                    "[Login]",
                    "Cline 登录任务已不在表中，结果未写回（账号仍已保存）",
                );
                return;
            };
            match result {
                Ok(account_id) => {
                    let account = store
                        .cline_account_record(&task_provider, &account_id)
                        .and_then(|record| {
                            record
                                .get("account")
                                .and_then(Value::as_str)
                                .map(str::to_string)
                        })
                        .unwrap_or_default();
                    // 复用 workbuddy 那条链路的会话摘要形状，前端不需要新分支
                    finish_task(
                        &handle,
                        &json!({
                            "account": { "uid": account_id, "nickname": account },
                            "edition": "",
                        }),
                    );
                }
                Err(error) => finish_task_error(&handle, &error.message),
            }
        });
        Ok(handle)
    }

    /// 等 authUrl（对应 Node 版 `/api/session/login/start` 的 15 秒等待）。
    ///
    /// 返回 `(state, authUrl, edition)`；超时或任务提前失败时返回错误原因。
    /// 任务本身不受影响，仍在后台轮询（与 Node 版一致：返回 502 不代表任务停了）。
    pub async fn wait_for_auth_url(
        &self,
        handle: &LoginTaskHandle,
        timeout: Duration,
    ) -> Result<(String, String, String), String> {
        let deadline = tokio::time::Instant::now() + timeout;
        loop {
            let task = handle.snapshot();
            if let (Some(state), Some(url)) = (task.state.clone(), task.auth_url.clone()) {
                // authUrl 拿到即登记进任务表，/wait 才能按 state 查到
                self.tasks.register(&state, handle.clone());
                return Ok((state, url, task.edition));
            }
            if task.done {
                return Err(task
                    .error
                    .clone()
                    .unwrap_or_else(|| "上游登录服务未返回登录链接".to_string()));
            }
            if tokio::time::Instant::now() >= deadline {
                return Err("上游登录服务未返回登录链接".to_string());
            }
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
    }

    /// 跑一次完整登录（同步等完成，供 POST /auth/login 用）。
    ///
    /// 与 `start()` 的区别：这里**亲自 await 登录流程**，不起后台任务 ——
    /// 命令行入口要的就是「等登录完成才响应」。任务句柄仍然建一个，
    /// 这样 authUrl 能被回调写进去（日志用它打印链接），登录结果也能
    /// 被 `/api/session/login/wait` 查到（与 Node 版共用 loginTasks 一致）。
    pub async fn run_login(&self, region: Region) -> Result<Value, WorkBuddyAuthError> {
        let info = region.edition();
        logging::log(
            "[Login]",
            &format!("发起{}登录（{}）…", info.label, info.endpoint),
        );
        let handle = self.new_handle(region);
        let session = self
            .login_interactive(region, &handle, |url, _state| {
                logging::log("[Login]", "请在浏览器中打开以下链接并完成登录：");
                logging::console_line("[Login]", &format!("  {url}"));
                logging::log("[Login]", "登录完成后本网关将自动获取并保存 token…");
            })
            .await;
        match &session {
            Ok(value) => {
                if let Some(state) = handle.snapshot().state {
                    self.tasks.register(&state, handle.clone());
                }
                finish_task(&handle, value);
                logging::log(
                    "[Login]",
                    &format!(
                        "✅ 登录完成（{}，账号 {}）",
                        info.label,
                        value
                            .get("account")
                            .and_then(|account| account.get("uid"))
                            .and_then(Value::as_str)
                            .unwrap_or("未知")
                    ),
                );
            }
            Err(error) => {
                let message = error.message.clone();
                finish_task_error(&handle, &message);
                logging::log("[Login]", &format!("❌ 登录失败: {message}"));
            }
        }
        session
    }

    /// 收一次**网页登录回调**：校验 state → 换凭证 → 落账号 → 标记任务完成。
    ///
    /// ── 为什么回调要由登录窗口提交进来 ──────────────────────────
    /// 小浣熊的官方回调是自定义协议 `office-raccoon://auth/callback`。Electron
    /// 版能在会话内 `protocol.handle('office-raccoon', …)` 接管它，Tauri/WebView2
    /// **没有等价物**：WebView2 的 NavigationStarting 只是「导航前问一句要不要
    /// 拦」，而自定义协议导航一旦放行就会交给系统处理（本机没注册该协议时是
    /// 一个失败页）。因此壳侧的做法是：**在导航拦截里认出回调 URL、拦下导航、
    /// 把 URL 原样 POST 到本接口**（见 `src-tauri/src/login.rs`）。
    ///
    /// ── state 校验（安全口径）───────────────────────────────────
    /// 这一步是整条链路上**唯一**能确认「这个 code 是本次登录的回调」的地方：
    /// 任务表按 state 索引，且 state 是本进程刚生成的不可预测随机串。少了它，
    /// 任何本机程序都能构造一个回调 URL 让网关用**别人的** code 换凭证并落进
    /// 本机账号库（等于把陌生人的登录态塞给用户）。因此：
    ///   1. 任务必须存在（不存在 → 404「请重新发起」）；
    ///   2. 回调里的 state 必须与任务里的逐字一致（`parse_callback_code`）；
    ///   3. 任务必须还没结束（重复提交同一个回调 → 直接返回成功，不重复换码，
    ///      因为授权码是一次性的：重复调用只会拿到 200035「已失效」的错误，
    ///      把一次成功登录变成一次失败）。
    ///
    /// 返回成功时的账号 id（前端不用它，留给日志与将来可能的「登录后高亮新账号」）。
    pub async fn submit_login_callback(
        &self,
        state: &str,
        callback_url: &str,
    ) -> Result<LoginCallbackSubmission, GatewayError> {
        let state = state.trim();
        if state.is_empty() {
            return Err(GatewayError::with_status(400, "缺少 state，无法确认这次回调归属"));
        }
        let Some(handle) = self.tasks.get(state) else {
            return Err(GatewayError::with_status(
                404,
                "登录任务不存在或已过期，请重新发起网页登录",
            ));
        };
        let task = handle.snapshot();
        if task.canceled {
            return Err(GatewayError::with_status(400, "登录已取消，请重新发起"));
        }
        if task.done {
            // 幂等：同一个回调被送来两次（深链 + 导航各触发一次）不是错误
            return Ok(LoginCallbackSubmission::Completed(String::new()));
        }
        // provider 由任务记着，不由调用方决定（见 LoginTaskState::provider）
        let Some(kind) = kind_from_id(&task.provider) else {
            return Err(GatewayError::with_status(
                500,
                format!("登录任务记录的提供商「{}」无法识别", task.provider),
            ));
        };
        // CodeArts：粘贴回来的整条回调 URL 在这里收尾。
        // 为什么不是「按 state 取 code」那套：portal 的回调**可能只带一个 code**、
        // 不带我们的配对信息，收尾要「逐个候选试 verifier」，还要认第一次回调下发的
        // secret（ticket 兜底通道）。整套判定都在 `core::login::codearts` 里，
        // 这里只负责把 URL 的查询串拆给它。
        if kind == ProviderKind::CodeArts {
            let params: std::collections::HashMap<String, String> = url::Url::parse(callback_url)
                .ok()
                .map(|parsed| {
                    parsed
                        .query_pairs()
                        .map(|(key, value)| (key.into_owned(), value.into_owned()))
                        .collect()
                })
                .unwrap_or_default();
            return match self.finish_codearts_login(&params).await {
                codearts::Callback::ContinueTo(url) => Ok(LoginCallbackSubmission::ContinueTo(url)),
                codearts::Callback::Accepted(account_id, _) => {
                    Ok(LoginCallbackSubmission::Completed(account_id.unwrap_or_default()))
                }
                codearts::Callback::Failed(status, message) => Err(GatewayError::with_status(i32::from(status), message)),
            };
        }
        // Trae 的上游回调地址带随机 loopback 端口，远程浏览器无法直接访问
        // 容器内监听器。手工粘贴时仍把**原始 query**注入同一个 listener，
        // 由原有 `Session::complete` 继续完成换证与落账号，避免复制另一套
        // Trae 登录逻辑。
        if kind == ProviderKind::Trae {
            let parsed = url::Url::parse(callback_url).map_err(|_| {
                GatewayError::with_status(400, "Trae 登录回调地址无效")
            })?;
            if parsed.path() != crate::server::core::providers::trae::oauth::CALLBACK_PATH {
                return Err(GatewayError::with_status(400, "Trae 登录回调地址无效"));
            }
            let query = parsed.query().unwrap_or_default();
            let session = self
                .trae_login()
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .get(state)
                .cloned()
                .ok_or_else(|| GatewayError::with_status(404, "Trae 登录上下文已结束，请重新发起"))?;
            session
                .submit_callback(query)
                .map_err(|message| GatewayError::with_status(400, message))?;
            return Ok(LoginCallbackSubmission::Completed(String::new()));
        }
        // Accio 的回调是标准 `code/state` 查询串。与 public callback 路由
        // 共用同一收尾函数，保证 PKCE pending、一次性消费和幂等语义一致。
        if matches!(kind, ProviderKind::Accio | ProviderKind::AccioCn) {
            let parsed = url::Url::parse(callback_url).map_err(|_| {
                GatewayError::with_status(400, "Accio 登录回调地址无效")
            })?;
            let params: std::collections::HashMap<String, String> = parsed
                .query_pairs()
                .map(|(key, value)| (key.into_owned(), value.into_owned()))
                .collect();
            let code = params.get("code").map(String::as_str).unwrap_or("");
            let callback_state = params.get("state").map(String::as_str).unwrap_or("");
            if let Some(error) = params.get("error").filter(|value| !value.trim().is_empty()) {
                return Err(GatewayError::with_status(400, format!("授权被拒绝（{error}）")));
            }
            if callback_state.trim() != state {
                return Err(GatewayError::with_status(400, "回调地址与当前 Accio 登录任务不匹配"));
            }
            let result = self.finish_accio_login(code, callback_state).await;
            if result.is_err() {
                self.drop_accio_pending(state);
            }
            return result.map(LoginCallbackSubmission::Completed);
        }
        // Antigravity 的回调同样是标准 `code` / `state` 查询串（Google OAuth
        // 授权码 + loopback）。与 Accio 同款，这里同时服务两个入口：
        //   ① 浏览器直接落到网关的 `/oauth-callback` 路由（public 回调 handler
        //      把 URL 转交进来）；
        //   ② 网页端 / Docker 用户在登录弹窗里手工粘贴整条回调 URL（浏览器
        //      到不了容器内的 loopback 端口时）。
        // 两条入口的收尾完全一致：state 与任务逐字比对 → 适配器换码落账号。
        if kind == ProviderKind::Antigravity {
            let parsed = url::Url::parse(callback_url).map_err(|_| {
                GatewayError::with_status(400, "Antigravity 登录回调地址无效")
            })?;
            let params: std::collections::HashMap<String, String> = parsed
                .query_pairs()
                .map(|(key, value)| (key.into_owned(), value.into_owned()))
                .collect();
            if let Some(error) = params.get("error").filter(|value| !value.trim().is_empty()) {
                return Err(GatewayError::with_status(400, format!("授权被拒绝（{error}）")));
            }
            let callback_state = params.get("state").map(String::as_str).unwrap_or("");
            let code = params.get("code").map(String::as_str).unwrap_or("");
            if callback_state.trim() != state {
                return Err(GatewayError::with_status(400, "回调地址与当前 Antigravity 登录任务不匹配"));
            }
            return match adapter_for(kind)
                .exchange_login_code(&self.store, code, state)
                .await
            {
                Ok(account_id) => {
                    let session = json!({
                        "accountUid": account_id,
                        "nickname": Value::Null,
                        "edition": task.edition,
                        "provider": task.provider,
                    });
                    handle.update(|task| {
                        task.done = true;
                        task.session = Some(session);
                        task.finished_at = Some(logging::now_ms());
                    });
                    Ok(LoginCallbackSubmission::Completed(account_id))
                }
                Err(error) => {
                    // 与 Accio / Raccoon 同一处置：失败要落定任务错误，
                    // 否则前端会一直等到 5 分钟超时
                    finish_task_error(&handle, &error.message);
                    logging::log(
                        "[Login]",
                        &format!("❌ Antigravity 网页登录换取凭证失败: {}", error.message),
                    );
                    Err(error)
                }
            };
        }
        // AutoClaw OAuth 回调 URL 里没有网关自己的 task state，手工提交时由
        // 请求体的 state 先锁定这次任务，再按回调路径识别 Zai / Google。
        if crate::server::core::providers::autoclaw::Region::from_provider_id(&task.provider).is_some() {
            let parsed = url::Url::parse(callback_url).map_err(|_| {
                GatewayError::with_status(400, "AutoClaw 登录回调地址无效")
            })?;
            let Some(vendor_id) = parsed
                .path()
                .strip_prefix(crate::server::core::providers::autoclaw::oauth::CALLBACK_PATH_PREFIX)
            else {
                return Err(GatewayError::with_status(400, "AutoClaw 登录回调地址无效"));
            };
            let vendor = crate::server::core::providers::autoclaw::oauth::Vendor::from_id(vendor_id)
                .ok_or_else(|| GatewayError::with_status(400, "无法识别 AutoClaw 登录方式"))?;
            let params: std::collections::HashMap<String, String> = parsed
                .query_pairs()
                .map(|(key, value)| (key.into_owned(), value.into_owned()))
                .collect();
            if let Some(error) = params.get("error").filter(|value| !value.trim().is_empty()) {
                return Err(GatewayError::with_status(400, format!("授权被拒绝（{error}）")));
            }
            let upstream_state = params.get("state").map(String::as_str).unwrap_or("");
            let code = params.get("code").map(String::as_str).unwrap_or("");
            let Some((pending_state, _)) = self.find_autoclaw_pending_for_vendor(vendor) else {
                return Err(GatewayError::with_status(404, "AutoClaw 登录上下文已结束，请重新发起"));
            };
            if pending_state != state {
                return Err(GatewayError::with_status(400, "回调地址与当前 AutoClaw 登录任务不匹配"));
            }
            return self
                .finish_autoclaw_oauth_callback(vendor, upstream_state, code)
                .await
                .map(LoginCallbackSubmission::Completed);
        }
        // OrcaTerm 的回调是官方桌面端的自定义协议
        // （`orcaterm://oauth_callback?session_id=…`）：URL 里带的是 `session_id`
        // 而不是 `code`，换令牌走匿名 CGI 动作 `OAuthExchangeToken`
        // （见 `providers/orcaterm/login.rs` 模块头）。与 Antigravity 同款收尾：
        // 换码失败要落定任务错误，否则前端会一直等到 5 分钟超时。
        if kind == ProviderKind::OrcaTerm {
            return match adapter_for(kind)
                .exchange_login_code(&self.store, callback_url, state)
                .await
            {
                Ok(account_id) => {
                    let session = json!({
                        "accountUid": account_id,
                        "nickname": Value::Null,
                        "edition": task.edition,
                        "provider": task.provider,
                    });
                    handle.update(|task| {
                        task.done = true;
                        task.session = Some(session);
                        task.finished_at = Some(logging::now_ms());
                    });
                    Ok(LoginCallbackSubmission::Completed(account_id))
                }
                Err(error) => {
                    finish_task_error(&handle, &error.message);
                    logging::log(
                        "[Login]",
                        &format!("❌ OrcaTerm 网页登录换取凭证失败: {}", error.message),
                    );
                    Err(error)
                }
            };
        }
        // CatPaw 正常情况下由服务端 poll-token 兜底完成；若上游仍把 token
        // 放进可复制的查询串，这里也复用 public callback 的收尾逻辑。
        if kind == ProviderKind::CatPaw {
            let parsed = url::Url::parse(callback_url).map_err(|_| {
                GatewayError::with_status(400, "CatPaw 登录回调地址无效")
            })?;
            let params: std::collections::HashMap<String, String> = parsed
                .query_pairs()
                .map(|(key, value)| (key.into_owned(), value.into_owned()))
                .collect();
            let token = params.get("token").map(String::as_str).unwrap_or("");
            let callback_state = params.get("state").map(String::as_str).unwrap_or(state);
            if !params.get("state").map(String::as_str).unwrap_or("").trim().is_empty()
                && callback_state.trim() != state
            {
                return Err(GatewayError::with_status(400, "回调地址与当前 CatPaw 登录任务不匹配"));
            }
            self.finish_catpaw_login(token, callback_state)
                .await
                .map(|_| LoginCallbackSubmission::Completed(String::new()))
                .map_err(|message| GatewayError::with_status(400, message))
        } else {
            if kind != ProviderKind::Raccoon {
                return Err(GatewayError::with_status(400, "该登录任务不接收授权码回调"));
            }
            let code = match oauth::parse_callback_code(callback_url, state) {
                Ok(code) => code,
                Err(error) => {
                    // 校验失败也要落定任务：否则前端会一直等到 5 分钟超时
                    finish_task_error(&handle, &error.message);
                    logging::log("[Login]", &format!("❌ 网页登录回调校验失败: {}", error.message));
                    return Err(error);
                }
            };
            match adapter_for(kind).exchange_login_code(&self.store, &code, state).await {
                Ok(account_id) => {
                    let session = json!({
                        "accountUid": account_id,
                        "nickname": Value::Null,
                        "edition": task.edition,
                        "provider": task.provider,
                    });
                    handle.update(|task| {
                        task.done = true;
                        task.session = Some(session);
                        task.finished_at = Some(logging::now_ms());
                    });
                    Ok(LoginCallbackSubmission::Completed(account_id))
                }
                Err(error) => {
                    finish_task_error(&handle, &error.message);
                    logging::log("[Login]", &format!("❌ 网页登录换取凭证失败: {}", error.message));
                    Err(error)
                }
            }
        }
    }

    /// 后台起一个登录任务，并把「失败/完成」写回任务句柄。
    fn spawn_login(&self, handle: LoginTaskHandle, region: Region) {
        let this = self.clone();
        crate::spawn_task(async move {
            let handle_for_callback = handle.clone();
            let result = this
                .login_interactive(region, &handle, move |url, state| {
                    // 回调发生在轮询任务内：把 authUrl/state 落进句柄，
                    // 让 /start 的等待与 /wait 的轮询都能看到
                    let state = state.map(str::to_string);
                    handle_for_callback.update(|task| {
                        task.phase = "waiting".into();
                        task.expires_at=logging::now_ms()+LOGIN_TIMEOUT_MS as i64;
                        task.auth_url = Some(url.to_string());
                        task.state = state.clone();
                    });
                })
                .await;
            match result {
                Ok(session) => {
                    if let Some(state) = handle.snapshot().state {
                        this.tasks.register(&state, handle.clone());
                    }
                    let account_uid = session
                        .get("account")
                        .and_then(|account| account.get("uid"))
                        .and_then(Value::as_str)
                        .unwrap_or("未知")
                        .to_string();
                    finish_task(&handle, &session);
                    logging::log(
                        "[Login]",
                        &format!(
                            "✅ 登录任务完成（{}，账号 {account_uid}）",
                            crate::server::core::providers::label_of(region.provider_id())
                        ),
                    );
                }
                Err(error) => {
                    let canceled = handle.snapshot().canceled;
                    let message = error.message.clone();
                    finish_task_error(&handle, &message);
                    if canceled {
                        logging::log("[Login]", "登录任务已取消");
                    } else {
                        logging::log("[Login]", &format!("❌ 登录任务失败: {message}"));
                    }
                }
            }
        });
    }

    /// 登录主流程（对照 `loginInteractive`）。
    ///
    /// 每拍轮询前检查任务的 `canceled` 标记 —— 等价 Node 的 `signal.aborted`。
    async fn login_interactive(
        &self,
        region: Region,
        handle: &LoginTaskHandle,
        on_auth_url: impl Fn(&str, Option<&str>),
    ) -> Result<Value, WorkBuddyAuthError> {
        // 端点覆盖按本地区取（staging / 自建反向代理用户的落点，见
        // `Region::env_endpoint_override`）
        let context: Context = context_for_edition(
            Some(region.id()),
            region.env_endpoint_override().as_deref(),
        );
        let headers = anonymous_headers();
        let url = context.auth_url(&format!(
            "/auth/state?platform={}",
            urlencoding(&context.platform)
        ));
        let response = send_public_request("POST", &url, Some(&json!({})), &headers).await?;
        let state_data = unwrap_public_response(&response, "auth/state")?;
        let state = state_data
            .get("state")
            .or_else(|| state_data.get("authState"))
            .and_then(Value::as_str)
            .map(str::to_string);
        let auth_url = state_data
            .get("authUrl")
            .and_then(Value::as_str)
            .map(str::to_string);
        if state.as_deref().is_none_or(|s| s.is_empty()) || auth_url.as_deref().is_none_or(|s| s.is_empty()) {
            return Err(WorkBuddyAuthError::new(
                "auth/state 未返回 state/authUrl，无法发起登录",
            ));
        }
        if let Some(url) = &auth_url {
            on_auth_url(url, state.as_deref());
        }
        let state = state.unwrap_or_default();

        let deadline = tokio::time::Instant::now() + Duration::from_millis(LOGIN_TIMEOUT_MS);
        while tokio::time::Instant::now() < deadline {
            if handle.snapshot().canceled {
                return Err(WorkBuddyAuthError::new("登录已取消"));
            }
            tokio::time::sleep(Duration::from_millis(LOGIN_POLL_INTERVAL_MS)).await;
            if handle.snapshot().canceled {
                return Err(WorkBuddyAuthError::new("登录已取消"));
            }

            let token_url = context.auth_url(&format!("/auth/token?state={}", urlencoding(&state)));
            let token_data = match send_public_request("GET", &token_url, None, &headers).await {
                Ok(response) => match unwrap_public_response(&response, "auth/token") {
                    Ok(data) => data,
                    Err(error) => {
                        // 未完成登录时上游返回 code=11217，轮询期间一律继续等待
                        if error.upstream_code == Some(SERVER_CODE_RETRY_FETCH_TOKEN) {
                            logging::verbose("[Auth]", "等待浏览器登录完成…");
                        } else {
                            logging::verbose("[Auth]", &format!("登录轮询中: {}", error.message));
                        }
                        continue;
                    }
                },
                Err(error) => {
                    logging::verbose("[Auth]", &format!("登录轮询中: {}", error.message));
                    continue;
                }
            };

            let access_token = token_data
                .get("accessToken")
                .and_then(Value::as_str)
                .unwrap_or("");
            if !access_token.is_empty() {
                let mut session = self
                    .build_session_from_token(&token_data, &state, &context)
                    .await?;
                let uid = session
                    .get("account")
                    .and_then(|account| account.get("uid"))
                    .and_then(Value::as_str)
                    .unwrap_or("").to_string();
                if uid.is_empty() {
                    return Err(WorkBuddyAuthError::new(
                        "登录成功但获取账号信息失败（缺少 uid），请重试",
                    ));
                }
                // Cancellation and the local commit are serialized. Once saved,
                // cancel returns false and never removes the account.
                let mut commit=handle.lock();
                if commit.canceled {return Err(WorkBuddyAuthError::new("登录已取消"));}
                commit.phase="saving".into();
                let account_id=format!("user-{uid}");
                let updated=self.store.get_session_by_id(&account_id).is_some();
                let saved = self
                    .store
                    .add_account(&session, None, Some(region.provider_id()))
                    .map_err(|error| {
                        WorkBuddyAuthError::with_status(error.status_code, format!("保存账号失败: {}",error.message))
                    })?;
                commit.phase="saved".into();
                drop(commit);
                session["_loginUpdated"]=json!(updated);
                session["_accountId"]=json!(account_id);
                let name = saved
                    .get("name")
                    .and_then(Value::as_str)
                    .unwrap_or("")
                    .to_string();
                logging::log(
                    "[Auth]",
                    &format!(
                        "✅ 登录成功：{name}（{}…），已加入账号列表",
                        crate::server::core::account_store::store_util::truncate_text(&uid, 8)
                    ),
                );
                return Ok(session);
            }
            logging::verbose("[Auth]", "等待浏览器登录完成…");
        }
        Err(WorkBuddyAuthError::new(format!(
            "登录轮询超时（{} 分钟）",
            LOGIN_TIMEOUT_MS / 60000
        )))
    }

    /// 拿到 token 后拉账号：优先 `/login/account?state=`，再回退 `/accounts`
    /// （对照 `buildSessionFromToken`：两步都失败不影响登录本身）。
    async fn build_session_from_token(
        &self,
        auth: &Value,
        state: &str,
        context: &Context,
    ) -> Result<Value, WorkBuddyAuthError> {
        let enriched = with_expires_at(auth.clone());
        let mut account = Value::Object(serde_json::Map::new());
        let mut accounts: Vec<Value> = Vec::new();

        if !state.is_empty() {
            // 登录时机还没有任何账号上下文，因此这里的出口固定为直连
            // （Node 版登录请求同样不传 proxy）
            match self
                .auth
                .fetch_login_account(&enriched, state, context, None)
                .await
            {
                Ok(data) => {
                    if data.is_object() {
                        account = data;
                    }
                }
                Err(error) => logging::verbose(
                    "[Auth]",
                    &format!("login/account 拉取失败: {}", error.message),
                ),
            }
        }
        match self.auth.fetch_accounts(&enriched, context, None).await {
            Ok(list) => accounts = list,
            Err(error) => logging::log(
                "[Auth]",
                &format!("拉取账号列表失败（不影响登录）: {}", error.message),
            ),
        }
        // ── 身份的三步兜底（后一步只在前一步没给出 uid 时生效）──────
        //   ① `login/account`（上面那次调用）
        //   ② `/accounts` 列表里「最近登录过的那条」，退而求其次取第一条
        //   ③ access token 自己的 JWT 声明（见 `account_from_token_claims`）
        let account_uid = account.get("uid").and_then(Value::as_str).unwrap_or("");
        if account_uid.is_empty() {
            let fallback = accounts
                .iter()
                .find(|item| {
                    item.get("lastLogin")
                        .map(|value| !value.is_null())
                        .unwrap_or(false)
                })
                .or_else(|| accounts.first())
                .cloned()
                .unwrap_or_else(|| Value::Object(serde_json::Map::new()));
            account = fallback;
        }
        // ③ 最后一步是**网络之外**的来源，这一层不能少：
        //
        // 前两步都是网络调用，任何一条卡住就把整轮登录作废。2026-10-03 实测
        // （国际版，用户现场）：Chrome 里授权已经成功、token 也拿到了，只因
        // 紧接着的 `login/account` 连了 30 秒没连上（日志「连接上游超时」），
        // 用户看到的就是「登录成功但获取账号信息失败（缺少 uid），请重试」——
        // 而 uid 本来就在 token 里。资料接口的职责是把昵称等资料带得更全，
        // 身份不必依赖它们；补上这一层之后，「浏览器授权成功」在 token 可解
        // （上游常态）时就等于「账号一定落库」，资料接口全挂也只会少一个昵称。
        if account
            .get("uid")
            .and_then(Value::as_str)
            .unwrap_or("")
            .is_empty()
        {
            if let Some(from_token) = account_from_token_claims(&enriched) {
                logging::log(
                    "[Auth]",
                    "资料接口未给出 uid，已回退用 access token 的 JWT 声明（sub）",
                );
                account = from_token;
            }
        }

        Ok(json!({
            "endpoint": context.base_url,
            "prefixPath": context.prefix,
            "platform": context.platform,
            "edition": context.edition,
            "auth": enriched,
            "account": account,
            "accounts": accounts,
            "lastRefreshTime": logging::now_ms(),
        }))
    }
}

/// 从 access token 的 JWT 声明里取账号身份（`uid` + 昵称）。
///
/// ── 为什么 token 里就有（2026-10-03 实测）────────────────────
/// 上游签发的是 Keycloak 风格 JWT，`sub` **就是账号主键**：实测 CN 账号的
/// `sub` 与库里既有记录的 uid 逐字相同（记录 id 形如 `user-<uid>`），
/// `nickname` 是上游给的用户名（账号页显示的就是它），更次一档的展示名来源是
/// `preferred_username` 与 `email`。国际版是同一套结构（`iss` 换成它自己的
/// realm），`sub` 同样是上游主键。
///
/// 这一路只在**两条资料接口都没给出 uid** 时才走（见
/// `build_session_from_token` 的第三步兜底），正常路径行为一字不变。
///
/// 只解 payload、不验签：网关不做鉴权判定，token 能不能用由上游说了算
/// —— 与 `raccoon::jwt` 同一纪律（那份解码是与 provider 无关的纯函数，
/// 本文件的登录流程本来也已经 import 了 `raccoon::oauth`）。
fn account_from_token_claims(auth: &Value) -> Option<Value> {
    let token = auth.get("accessToken").and_then(Value::as_str)?;
    let claims = crate::server::core::providers::raccoon::jwt::decode_jwt_claims(token)?;
    let uid = text_of(&claims, &["sub", "userId", "uid"]);
    if uid.is_empty() {
        return None;
    }
    let mut account = serde_json::Map::new();
    account.insert("uid".to_string(), Value::String(uid));
    // 昵称：`nickname` 优先（CN 是真实姓名），退到用户名 / 邮箱；
    // 都没有就不出这个键 —— 账号存储会按 uid 生成「账号 xxxxxxxx」的兜底名
    let name = text_of(
        &claims,
        &["nickname", "name", "preferred_username", "email"],
    );
    if !name.is_empty() {
        account.insert("nickname".to_string(), Value::String(name));
    }
    Some(Value::Object(account))
}

/// 取候选键里第一个非空字符串（去空白）
fn text_of(object: &Value, keys: &[&str]) -> String {
    for key in keys {
        if let Some(text) = object.get(*key).and_then(Value::as_str) {
            let text = text.trim();
            if !text.is_empty() {
                return text.to_string();
            }
        }
    }
    String::new()
}

/// 标记任务完成并写入会话摘要
fn finish_task(handle: &LoginTaskHandle, session: &Value) {
    let summary = json!({
        "updated":session.get("_loginUpdated").and_then(Value::as_bool).unwrap_or(false),
        "accountId":session.get("_accountId"),
        "accountUid": session
            .get("account")
            .and_then(|account| account.get("uid"))
            .cloned()
            .unwrap_or(Value::Null),
        "nickname": session
            .get("account")
            .and_then(|account| account.get("nickname"))
            .cloned()
            .unwrap_or(Value::Null),
        "edition": session
            .get("edition")
            .and_then(Value::as_str)
            .unwrap_or_default(),
    });
    handle.update(|task| {
        task.done = true;
        task.session = Some(summary);
        task.finished_at = Some(logging::now_ms());
    });
}

/// 标记任务失败（保留 cancel 与否交给调用方判断日志措辞）
fn finish_task_error(handle: &LoginTaskHandle, message: &str) {
    let message = message.to_string();
    handle.update(|task| {
        task.done = true;
        task.error = Some(message.clone());
        task.finished_at = Some(logging::now_ms());
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 造一个 `header.payload.签名` 形态的 token（只用于本地解析，不验签）。
    fn fake_token(claims: Value) -> String {
        use base64::Engine;
        let engine = base64::engine::general_purpose::URL_SAFE_NO_PAD;
        let header = engine.encode(br#"{"alg":"RS256","typ":"JWT"}"#);
        let payload = engine.encode(serde_json::to_vec(&claims).expect("声明可序列化"));
        format!("{header}.{payload}.signature")
    }

    /// 与线上同构的 token 声明。**值全是构造出来的示例** —— 真实账号的
    /// 姓名 / 手机号 / uid 一律不进仓库（测试要的是字段名与层级，不是谁的数据）。
    fn sample_claims() -> Value {
        json!({
            "sub": "11111111-2222-4333-8444-555555555555",
            "nickname": "示例用户",
            "preferred_username": "sample-user",
            "iss": "https://idp.invalid/auth/realms/copilot",
            "aud": "account",
            "typ": "Bearer"
        })
    }

    /// uid 就写在 token 里 —— 这就是「资料接口两条都挂时登录不该失败」的依据。
    ///
    /// 2026-10-03 实测：国际版登录在浏览器里已经授权成功、token 也拿到了，
    /// 只因为紧接着的 `login/account` 连了 30 秒没连上（连接上游超时），
    /// 整轮登录被判死。而 `sub` 与账号存储里的 uid 逐字相同
    /// （记录 id 形如 `user-<uid>`）。
    #[test]
    fn uid_comes_from_token_subject() {
        let account =
            account_from_token_claims(&json!({ "accessToken": fake_token(sample_claims()) }))
                .expect("应当能从 token 里解出身份");
        assert_eq!(account["uid"], "11111111-2222-4333-8444-555555555555");
        // 昵称是账号页显示的那个名字（账号存储按 `account.nickname` 取）
        assert_eq!(account["nickname"], "示例用户");
    }

    /// 昵称的退档顺序：没有 `nickname` 就退到用户名 / 邮箱；都没有就不出这个键
    /// （账号存储会按 uid 生成「账号 xxxxxxxx」的兜底名）。
    #[test]
    fn nickname_falls_back_then_may_be_absent() {
        let username = account_from_token_claims(&json!({
            "accessToken": fake_token(json!({ "sub": "u-1", "preferred_username": "sample-user" }))
        }))
        .expect("有 sub 就应当能解出身份");
        assert_eq!(username["nickname"], "sample-user");

        let email = account_from_token_claims(&json!({
            "accessToken": fake_token(json!({ "sub": "u-2", "email": "user@example.invalid" }))
        }))
        .expect("有 sub 就应当能解出身份");
        assert_eq!(email["nickname"], "user@example.invalid");

        let bare = account_from_token_claims(&json!({
            "accessToken": fake_token(json!({ "sub": "u-3" }))
        }))
        .expect("有 sub 就应当能解出身份");
        assert_eq!(bare["uid"], "u-3");
        assert!(
            bare.get("nickname").is_none(),
            "没有可用展示名时不该出这个键"
        );
    }

    /// 不是 JWT（上游换成不透明 token）／没有 sub／没有 accessToken：
    /// 一律返回 None，让调用方维持原来的报错 —— 不能凭一个空对象伪造身份。
    #[test]
    fn opaque_or_subjectless_token_yields_none() {
        assert!(
            account_from_token_claims(&json!({ "accessToken": "opaque-token-not-a-jwt" }))
                .is_none()
        );
        assert!(account_from_token_claims(&json!({
            "accessToken": fake_token(json!({ "nickname": "无 sub" }))
        }))
        .is_none());
        assert!(account_from_token_claims(&json!({})).is_none());
        // 手改/截断的 token 不能 panic（release 是 panic=abort）
        assert!(account_from_token_claims(&json!({ "accessToken": "a.!!!.c" })).is_none());
    }
}

#[cfg(test)]
mod qr_lifecycle_tests {
    use super::*;
    fn task(phase:&str)->LoginTaskHandle {LoginTaskHandle{ticket:1,inner:Arc::new(Mutex::new(LoginTaskState{state:Some("fixture-state".into()),phase:phase.into(),expires_at:12345,..Default::default()}))}}
    #[test]fn pending_cancel_removes_only_that_round(){let tasks=LoginTasks::new();let first=task("waiting");tasks.register("first",first.clone());let second=LoginTaskHandle{ticket:2,..task("waiting")};tasks.register("second",second);assert!(tasks.cancel("first"));assert!(first.snapshot().canceled);assert!(tasks.get("first").is_none());assert!(tasks.get("second").is_some());}
    #[test]fn saved_commit_cannot_be_cancelled(){let tasks=LoginTasks::new();let handle=task("saved");tasks.register("done",handle.clone());assert!(!tasks.cancel("done"));assert!(!handle.snapshot().canceled);assert!(tasks.get("done").is_some());}
    #[test]fn qr_wait_returns_summary_not_credentials(){let handle=task("saved");finish_task(&handle,&json!({"account":{"uid":"demo","nickname":"示例"},"auth":{"accessToken":"must-not-leak"},"_loginUpdated":true,"_accountId":"user-demo"}));let result=handle.snapshot().to_wait_response();assert_eq!(result["session"]["updated"],true);assert_eq!(result["session"]["accountId"],"user-demo");assert!(!result.to_string().contains("must-not-leak"));}
    #[test]fn waiting_exposes_server_expiry(){let handle=task("waiting");let result=handle.snapshot().to_wait_response();assert_eq!(result["expiresAt"],12345);assert_eq!(result["phase"],"waiting");}
}
