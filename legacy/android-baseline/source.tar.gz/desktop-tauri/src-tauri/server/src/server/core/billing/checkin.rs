//! 账号级签到：目标集合解析 + 串行执行（对照 Node 版 workbuddy-account-routes.mjs
//! 的 `resolveCheckinTargets` / `checkinFor` / `runCheckin` 三个函数逐条移植）。
//!
//! ── 为什么下沉到 core ───────────────────────────────────────
//! 定时签到（core::auto_checkin，对照 workbuddy-auto-checkin.mjs）与
//! `POST /api/accounts/checkin` 必须是**同一段逻辑**。Node 版靠依赖注入做到这点：
//! `createAutoCheckin({ runCheckin: id => accountRoutes.runCheckin(id) })` ——
//! 调度器拿到的就是账号路由里那个函数，所以「限额跳过、国际版排除、串行防风」
//! 的规则只维护一份，不存在两套行为。
//!
//! Rust 侧的 core 不能依赖 api（core 不认识 axum，见 core/mod.rs 的约定），
//! 于是把这段共享逻辑放到这里：api/accounts.rs 与 core/auto_checkin 各自持有
//! store / billing 句柄调用它，规则依旧只有一份。调用方负责把 `CheckinError`
//! 翻成响应（api 层用管理信封，调度器只取 message 记进 lastResult）。//!
//! ── 签到不看 `enabled`（本次改动；此前两轮口径相反）─────────
//! `enabled` 管的是「别让这个账号承接转发」，签到则是用户对某个账号显式发起的
//! 一次动作（定时签到则是调度器对所有账号的统一动作），与转发无关：一个被禁用的
//! 账号依然可以每天签到攒积分。所以单账号与批量两条路径都**不看** `enabled` ——
//! 禁用账号照常进入签到目标集合，界面上照常有签到按钮。
//!
//! ── 历史（别又改回去）────────────────────────────────────────
//! 这里先后有过两种相反口径：先是单账号路径漏查 `enabled`（当时算 bug ——
//! 「显式指定就什么都不看」被过度执行了，于是对禁用账号点签到会真的打上游），
//! 修成「单账号 400 / 批量过滤」；再是现在这次全部放开。中间那版把「禁用转发」
//! 与「禁止签到」当成了一件事 —— 但签到消耗的是**积分额度**，与转发配额不是
//! 同一个池子，用户对禁用账号点「签到」本身就是明确意图，替他拦下来反而多余。
//!
//! 仍然要看的只剩两处，两条路径各自一致：`available`（批量路径过滤，单账号不看 ——
//! Node 版既定语义：账号暂时不可用不影响手动操作）与 `supports_checkin`
//! （没有签到/活跃任务的家，两条路径都排除；WorkBuddy 国际版由活跃任务链放行）。
//!
//! ── `skipped` 的分母 ────────────────────────────────────────
//! 「可用账号总数 − 可签到数」，只可能由**不支持签到/活跃任务的版本**与**范围外
//! 提供商**两类构成（`enabled` 不再参与），与 /api/accounts/usage 的「只算被禁用的」
//! 口径不同 —— 两个动作的「不适用」集合本来就不一样。

use serde_json::{json, Value};

use crate::server::core::account_store::AccountStore;
use crate::server::core::billing::BillingService;
use crate::server::core::billing::WorkbuddyActivity;
use crate::server::logging;

/// 签到路径上的错误。对应 Node 版抛出的 AccountStoreError：
/// 404「账号不存在」与 400「国际版账号暂不支持签到」。
#[derive(Clone, Debug)]
pub struct CheckinError {
    pub message: String,
    pub status_code: i32,
}

impl CheckinError {
    fn new(message: impl Into<String>, status_code: i32) -> Self {
        Self { message: message.into(), status_code }
    }
}

impl std::fmt::Display for CheckinError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "{}", self.message)
    }
}

/// 国际版没有签到活动，签到相关操作一律排除该版本账号
/// （Node: `account.edition !== 'intl'`）。
///
/// **Qoder 国际版已不再吃这条判据**（2026-10，issue #140）：国际版有独立的
/// 签到链路（带设备风控身份领「每日 100 Credits」，见 `providers::qoder::checkin`
/// 与 `qoder::risk`），在下面的 provider 判定里显式放行 —— 与 WorkBuddy
/// 国际版同一手法。拆家后两家 provider id 各自独立，放行判据按 id 写。
///
/// Accio 系（两个地区）**整家**也没有签到活动：上游客户端全包检索不到
/// 「签到 / checkin / 每日任务」的任何痕迹（见 `providers::accio` 的模块头）。
/// 它按 **provider id** 排除而不是 edition —— 两个地区都没有活动，而 provider
/// 是落盘契约，不会因为凭证里多一个字段而改变判定。
///
/// 这一步是**必需的**：不在范围的家会落到 `checkin_for` 的分派里，拿另一家的
/// 令牌去打错的签到接口只会稳定报错（见那里的最后两条分支）。
pub fn supports_checkin(account: &Value) -> bool {
    let provider = account
        .get("provider")
        .and_then(Value::as_str)
        .unwrap_or(crate::server::core::providers::DEFAULT_PROVIDER_ID);
    // WorkBuddy 国际版没有国内版的普通签到接口，但上游客户端把它接到同一条
    // 「每日活跃」调度上（活动探测 + 条件领取 + 免费模型保活），所以它**参与**
    // 签到目标集合，执行形态在 `checkin_for` 按 provider 分派（workbuddy-intl）。
    // 它的 provider id 是拆家后的独立 id，不与国内版共用 —— 放行必须写在
    // 下面的 edition 判定之前，否则会被「intl 一刀切」挡掉。
    if provider == crate::server::core::providers::workbuddy::Region::Intl.provider_id() {
        return true;
    }
    // Qoder 国际版同理（2026-10 拆家 + issue #140）：它有自己的签到链路
    // （带设备风控身份领「每日 100 Credits」，见 `providers::qoder::checkin`
    // 与 `qoder::risk`），放行同样必须写在 edition 判定之前。
    if provider == crate::server::core::providers::qoder::endpoints::Region::Global.provider_id() {
        return true;
    }
    if account.get("edition").and_then(Value::as_str) == Some("intl") {
        return false;
    }
    // CodeArts **参与**本链（2026-10 按用户要求纳入，见 `auto_checkin::CHECKIN_PROVIDERS`
    // 里那一条的说明）：它的每日福利是 ops 活动交付（三个接口、两套状态），形态与
    // 别家差别最大，所以在「今天还能不能再领」「要不要重试」这两件事上与签到同构 ——
    // 上面那条按 `edition` 的 intl 一刀切与本家无关（它没有版本概念，恒 cn）。
    // Trae 曾与 CodeArts 同列排除表；SOLO 转积分制后模型调用花的就是签到钱包
    // 那份钱，它已在 `providers::trae::checkin` 接入本链，不要再加回来。
    !crate::server::core::account_store::is_accio_family(provider)
}

/// 账号的提供商 id（缺失时按默认 provider 处理，与账号存储的兜底口径一致）。
///
/// 签到范围的判定按提供商分派：WorkBuddy 走腾讯的每日签到接口，小浣熊走
/// 桌面登录积分链路（`providers::raccoon::balance::claim_daily_grant`）——
/// 两家的接口互不相通，拿小浣熊的 token 去打腾讯的签到接口只会稳定报错。
fn provider_of(account: &Value) -> &str {
    account
        .get("provider")
        .and_then(Value::as_str)
        .unwrap_or(crate::server::core::providers::DEFAULT_PROVIDER_ID)
}

/// 该账号是否在本次签到的提供商范围内
fn matches_provider_filter(account: &Value, providers: &[String]) -> bool {
    providers.iter().any(|id| id == provider_of(account))
}

/// 账号快照里的「可用」判定（Node: `account.available !== false`）
fn is_available(account: &Value) -> bool {
    account
        .get("available")
        .and_then(Value::as_bool)
        .unwrap_or(true)
}

/// 这条会话是不是企业版账号（`account.enterpriseId` 非空）。
///
/// 企业版没有个人成长 / 补偿体系：上游对签到、活动补偿这类个人计费端点
/// 固定回 400 code 10001（参考实现 workbuddy2api-panel 的 A/B 实测，
/// 2026-10-07）。活动补偿那一步据此直接跳过，省一次注定失败的请求 ——
/// 判据只此一份，与 `AuthService`「enterpriseId 为 null 就不显示企业标记」
/// 同一口径（空串按个人版处理）。
fn is_enterprise_session(session: &Value) -> bool {
    session
        .get("account")
        .and_then(|account| account.get("enterpriseId"))
        .and_then(Value::as_str)
        .is_some_and(|value| !value.is_empty())
}

/// 账号列表快照（`store.listAccounts().accounts`）
fn accounts_of(store: &AccountStore) -> Vec<Value> {
    store
        .list_accounts()
        .get("accounts")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default()
}

/// 签到目标集合。
///
/// 批量（`id` 为空）：可用账号 ∩ **提供商在 `providers` 范围内** ∩ 非国际版，
/// `skipped` = 可用总数 − 可签到数。范围由配置给出（WorkBuddy / 小浣熊 / AutoClaw
/// 可勾选），定时签到与账号页批量签到共用同一份口径。**禁用账号照常参与** ——
/// 签到与转发是两件事（见模块头「签到不看 enabled」）。
///
/// 指定 id：命中即用（**不过滤 available，也不过滤 provider**），
/// 国际版直接报 400 —— 用户点的是谁就签谁，与「显式指定就执行」的既有语义一致；
/// 批量路径必须过滤 available 与 provider，否则会把范围外的账号也签一遍。
///
/// ── 两条路径的「不满足条件」为什么语义不同（有意如此）──────────
///   批量路径 → **静默跳过**（计入 `skipped`）：定时任务会一次扫过几十个账号，
///     用户没在看着，为一个「国际版没有签到活动」把整轮任务报错没有意义。
///   单账号路径 → **明确 400 + 原因**：用户显式点了某个账号的按钮，
///     他需要知道为什么不行。静默成功或静默跳过都会让他以为签到了。
/// 所以 `supports_checkin` 在单账号路径报错、在批量路径过滤掉 ——
/// **不要为了「统一」把其中一处改掉**。
pub fn resolve_checkin_targets(
    store: &AccountStore,
    providers: &[String],
    id: Option<&str>,
) -> Result<(Vec<Value>, usize), CheckinError> {
    let all = accounts_of(store);
    if let Some(id) = id.filter(|value| !value.is_empty()) {
        let found: Vec<Value> = all
            .into_iter()
            .filter(|account| account.get("id").and_then(Value::as_str) == Some(id))
            .collect();
        if found.is_empty() {
            return Err(CheckinError::new("账号不存在", 404));
        }
        // 唯一的拒绝理由：上游这一站根本没有签到/活跃任务（Qoder 等的国际版）。
        // 文案与签到中心「范围外」分组那句同义 —— 两处说法不一致会让用户以为
        // 遇到的是两个不同的问题。WorkBuddy 国际版已由活跃任务分支放行。
        if !supports_checkin(&found[0]) {
            return Err(CheckinError::new("该账号暂不支持签到或每日活跃任务", 400));
        }
        return Ok((found, 0));
    }
    let available: Vec<Value> = all.into_iter().filter(is_available).collect();
    let total = available.len();
    let eligible: Vec<Value> = available
        .into_iter()
        .filter(supports_checkin)
        .filter(|account| matches_provider_filter(account, providers))
        .collect();
    let skipped = total - eligible.len();
    Ok((eligible, skipped))
}

/// 单个账号签到。已签到（上游非 0 code）不算错误，原样返回结果 ——
/// 前端把「今天已签到」显示成一条 warn 提示。
///
/// ── 按提供商分派（各家的接口互不相通）────────────────────────
///   - **WorkBuddy 国内版**：计费服务的每日签到（`billing.claim_daily_checkin`）；
///   - **WorkBuddy 国际版**：活跃探测、条件领取与免费模型保活
///     （`billing.workbuddy_daily_activity`，模型链可在签到中心自定义）；
///   - **小浣熊**：桌面登录积分链路（`providers::raccoon::balance::claim_daily_grant`）；
///   - **AutoClaw**：通用任务接口的 `daily_signin` 任务
///     （`providers::autoclaw::checkin::claim_daily_signin`）；
///   - **Qoder**：活动（campaign）领取链路，中国版直领；国际版要先带设备
///     风控身份重新拉活动列表（`providers::qoder::checkin` + `qoder::risk`）；
///     （`providers::qoder::checkin::claim_daily_checkin`）；
///   - **Trae**：SOLO 的 `checkin_credits` 领取（`providers::trae::checkin`）；
///   - **CodeArts**：当日 ops 福利（`providers::codearts::welfare` 的
///     delivery → claim → confirm → 回读核实）。它的「签到」是**写请求**，
///     受本家自己的限流闸约束，所以这一支要吃 `manual` 参数（见下）。
///
/// `manual` 只对 CodeArts 有意义（别家的签到接口幂等且无本地闸）：真值表示这次
/// 执行是**用户在面板上点出来的**（单账号 `single` / 批量 `manual`），假值表示
/// 无人值守的定时或启动补签。它决定 welfare 那两道闸（每天 ≤6 次写、间隔
/// ≥10 分钟）要不要生效 —— 闸保护的是无人值守的重试，不是用户的点击
/// （见 `providers::codearts::welfare` 的模块头）。
///
/// 拿一家的 token 去打另一家的签到接口只会稳定报错，所以这条分派是必需的而不是
/// 优化。各分支的收尾（claim → 结果行 + 日志）完全一致，共用 [`claim_result`]；
/// 各家的 claim 都由各自的实现对齐成 `{success, msg}` 形状。最后的兜底**只认**
/// 默认那家（WorkBuddy 国内版），未知家明确报「未接入」——见那里的说明。
pub async fn checkin_for(
    store: &AccountStore,
    billing: &BillingService,
    account: &Value,
    manual: bool,
) -> Value {
    let id = account.get("id").and_then(Value::as_str).unwrap_or("").to_string();
    // 结果行的 name 是**签到记录台账与前端结果卡的展示名快照**：优先读统一
    // 展示名 `displayName`（与账号页 / 请求日志同一口径，见
    // `store_view::display_name_of`；「以邮箱报名字」的三家在这里同样显示邮箱），
    // 缺键（旧快照 / 手工构造）按旧口径回落 `name`，再退 id。
    let name = account
        .get("displayName")
        .filter(|value| value.as_str().is_some_and(|text| !text.is_empty()))
        .cloned()
        .or_else(|| account.get("name").cloned())
        .unwrap_or(Value::Null);
    let display = name.as_str().unwrap_or(&id).to_string();
    // 分派的键就是账号的 provider id（`provider_of` 已归一）；AutoClaw 两个
    // 地区各是一个 provider，因此下面按 `region.provider_id()` 反查地区，
    // 而不是写死 `"autoclaw"`（那样国际版账号会掉进 `_` 分支）
    let provider_id = provider_of(account);
    match provider_id {
        "raccoon" => {
            let claim =
                crate::server::core::providers::raccoon::balance::claim_daily_grant(store, &id)
                    .await
                    .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "autoclaw" | "autoclaw-intl" => {
            let region = crate::server::core::providers::autoclaw::Region::from_provider_id(
                provider_id,
            )
            .unwrap_or(crate::server::core::providers::autoclaw::Region::Cn);
            let claim = crate::server::core::providers::autoclaw::checkin::claim_daily_signin(
                region, store, &id,
            )
            .await
            .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "qoder" | "qoder-intl" => {
            // Qoder 的每日权益以活动（campaign）形式下发，两个地区走同一条
            // 实现按地区分支：中国版直接领；国际版要先带设备风控身份重新拉
            // 活动列表（见 `qoder::checkin` 的模块头）。地区由 provider id
            // 反查（拆家后它就是身份），与 AutoClaw 两个地区的分派同款。
            let region = crate::server::core::providers::qoder::endpoints::Region::from_provider_id(
                provider_id,
            )
            .unwrap_or(crate::server::core::providers::qoder::endpoints::Region::Cn);
            let claim =
                crate::server::core::providers::qoder::checkin::claim_daily_checkin(store, region, &id)
                    .await
                    .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "trae" => {
            // SOLO 那一条通道的每日签到（`providers::trae::checkin`）。它的
            // `alreadyCompleted` / 中性结果都由实现自己给：活动未下发、
            // 凭据没有 deviceId、国际版谱系这三格都不算失败，也不落当日台账
            // （除"已签"那格），免得定时链把一次"没得签"当成"没签成"反复重打。
            let claim = crate::server::core::providers::trae::checkin::claim_daily_checkin(
                store, &id,
            )
            .await
            .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "workbuddy-intl" => {
            // WorkBuddy 国际版：没有国内版的普通签到接口，走「每日活跃」链路 ——
            // 探测活动 → 条件领取 → 免费模型保活 + 网页会话（`billing::activity`
            // 的 `workbuddy_daily_activity`，模型链配置见 `billing::keepalive`）。
            // 落 `checkinAt` 的判据是 [`day_completed`]：领取成功 / 上报成功 /
            // 网页会话建成任一即算「今日已完成」（活动模块下线时领取恒为
            // 「活动未开启」，但日活实际完成、积分异步到账，见 day_completed
            // 的说明）；读数细节在行的 `activity` 格。
            let Some(entry) = store.get_session_by_id(&id) else {
                return json!({
                    "id": id,
                    "name": name,
                    "claim": Value::Null,
                    "error": "没有可用凭证",
                });
            };
            let activity = billing
                .workbuddy_daily_activity(&entry.session, WorkbuddyActivity::Full)
                .await;
            let claim = activity
                .get("claim")
                .cloned()
                .unwrap_or_else(|| json!({ "success": false, "code": -1, "msg": "活跃任务未返回领取结果" }));
            let claim_success = claim.get("success").and_then(Value::as_bool).unwrap_or(false);
            let message = claim.get("msg").and_then(Value::as_str).unwrap_or("");
            if claim_success {
                logging::log("[Accounts]", &format!("账号 {display}: 签到成功"));
            } else {
                logging::log("[Accounts]", &format!("账号 {display}: WorkBuddy 国际版 {message}"));
            }
            json!({
                "id": id,
                "name": name,
                "claim": claim,
                "activity": activity.get("activity").cloned().unwrap_or(Value::Null),
                "error": Value::Null,
            })
        }
        "loomy" => {
            // Loomy 没有独立的签到接口：「每日赠送积分」由**每日首次登录**
            // 触发刷新（`POST /api/v1/points/first-login`，见 `loomy::checkin`
            // 的模块头）。自动签到框架对它就是「每天替账号打一次这个接口」。
            let claim =
                crate::server::core::providers::loomy::checkin::claim_daily_login(store, &id)
                    .await
                    .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "kuku" => {
            // KukuAI：「免费领积分」活动的每日任务（每日登录 / 完成一次对话），
            // 接口幂等（重复领 reward_point=0），见 `kuku::checkin` 的模块头。
            // 业务会话由实现内部换发 genflowpro STOKEN（`kuku::engine`）保障。
            let claim =
                crate::server::core::providers::kuku::checkin::claim_daily_checkin(store, &id)
                    .await
                    .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "officeace" => {
            // OfficeAce：`POST /v1/subscription/bonus/claim`（V11 签名）一次把当天
            // 所有可领的奖励（每日签到 + 一次性新人礼）发下来；一天一个活动只能领
            // 一次、重复领不报错，幂等由上游保证（见 `officeace::checkin` 模块头）。
            let claim =
                crate::server::core::providers::officeace::checkin::claim_daily_checkin(store, &id)
                    .await
                    .map_err(|error| error.message);
            claim_result(id, name, &display, true, claim)
        }
        "codearts" => {
            // CodeArts：当日 ops 福利（每日登录送积分那一组，`Rewards::DailyLogin`
            // ——一次性注册礼归新手福利，不在这里领，见 welfare 的模块头）。
            // 四步流程与限流闸都在实现里，这里只把结论翻成签到结果行。
            let claim = crate::server::core::providers::codearts::welfare::claim_account(
                store,
                &id,
                crate::server::core::providers::codearts::models::DEFAULT_BASE_URL,
                logging::now_ms(),
                manual,
            )
            .await
            .map_err(|error| error.message)
            .map(welfare_claim_of);
            claim_result(id, name, &display, true, claim)
        }
        "chatglm" => {
            // 智谱清言：本家的「签到」是**每日登录积分**
            // （`POST /chatglm/member-api/member/daily_login_score`，返回
            // `result.score` 为本次到账数）。访客账号没有积分体系，实现如实
            // 返回中性未领取（`success:false` + 说明文案），不落失败台账 ——
            // 见 `chatglm::checkin` 的模块头。
            let claim =
                crate::server::core::providers::chatglm::checkin::claim_daily_login_score(store, &id)
                    .await
                    .map_err(|error| error.message);
            // ── 领取类：会员积分活动与季节性活动 ────────────────────
            // 本家的「领取类」没有独立的界面入口，与 WorkBuddy 的一次性运营
            // 奖励同一处置：**挂在签到末尾顺带领**（活动期才有得领，非活动期
            // 实现自己回中性文案，不算失败）。读数细节进 `bonus` 格。
            // 注意顺序：`claim_result` 会消费 `id`，所以先领再构造结果行。
            let bonus =
                crate::server::core::providers::chatglm::checkin::claim_bonus(store, &id)
                    .await
                    .map_err(|error| error.message);
            let bonus_ok = bonus
                .as_ref()
                .ok()
                .and_then(|value| value.get("success").and_then(Value::as_bool))
                .unwrap_or(false);
            logging::log(
                "[Checkin]",
                &format!(
                    "智谱清言账号 {display}: 活动领取 {}",
                    if bonus_ok { "成功" } else { "无可领取" }
                ),
            );
            // ── 每日任务：任务中心 `categories[code=daily]` ─────────
            // 用户口径：每日任务接我们的每日签到（新手任务另走 onboarding）。
            // 与「每日登录积分」并列在同一次签到里执行：登录积分是签到本身，
            // 每日任务是签到后顺手领的日常。上游按天重置（UTC+8 零点），
            // 重复领幂等（`points_awarded:0`），见 `chatglm::tasks` 模块头。
            let daily =
                crate::server::core::providers::chatglm::tasks::claim_daily_tasks(store, &id)
                    .await
                    .map_err(|error| error.message);
            let mut row = claim_result(id, name, &display, true, claim);
            if let Some(object) = row.as_object_mut() {
                object.insert(
                    "bonus".to_string(),
                    match &bonus {
                        Ok(value) => value.clone(),
                        Err(message) => serde_json::json!({ "success": false, "msg": message }),
                    },
                );
                object.insert(
                    "dailyTasks".to_string(),
                    match &daily {
                        Ok(value) => value.clone(),
                        Err(message) => serde_json::json!({ "success": false, "msg": message }),
                    },
                );
            }
            row
        }
        // 兜底只服务默认那家（WorkBuddy 国内版）——**不是**「剩下所有家」。
        // 这里曾经是无所不包的 `_`：一个 provider 只要没在上面列出，就会拿自己的
        // 令牌去打腾讯的签到接口，稳定报错且看不出原因（Qoder 接入前正是这个处境）。
        // 现在落到这里的未知家明确报「未接入」，新增一家时忘了加分支会立刻暴露
        // （WorkBuddy 国际版拆家后是独立 id，走上面的 workbuddy-intl 分支）。
        _ if provider_id == crate::server::core::providers::DEFAULT_PROVIDER_ID => {
            let Some(entry) = store.get_session_by_id(&id) else {
                return json!({
                    "id": id,
                    "name": name,
                    "claim": Value::Null,
                    "error": "没有可用凭证",
                });
            };
            let claim = billing
                .claim_daily_checkin(Some(&entry.session))
                .await
                .map_err(|error| error.message);
            let mut row = claim_result(id, name, &display, false, claim);
            // ── 一次性运营奖励：挂在签到末尾顺带领 ────────────────
            // 新手礼包与活动补偿（如 2026-10 的 DeepSeek 故障补偿 500 积分）
            // 都没有自己的入口，官方口径是去「用量管理 / 个人中心」手动点领取
            // —— 网关替账号走这两下（参考实现 workbuddy2api-hub 的连登管家把
            // 两条一起挂在签到后，同一口径）。每号一次，已领 / 无可领取静默
            // 跳过，不影响签到结果本身；真的到账才出声（日志 + 行内读数）。
            // 企业版没有个人成长 / 补偿体系（上游固定回 400 code 10001），
            // 直接不发这两条。
            if !is_enterprise_session(&entry.session) {
                let mut rewards: Vec<Value> = Vec::new();
                for reward in [
                    billing.claim_gift(&entry.session).await,
                    billing.claim_compensation(&entry.session).await,
                ] {
                    match reward {
                        Ok(reward) => {
                            let credited = reward.get("success").and_then(Value::as_bool)
                                == Some(true)
                                && reward.get("credit").and_then(Value::as_i64).unwrap_or(0) > 0;
                            if credited {
                                let message =
                                    reward.get("msg").and_then(Value::as_str).unwrap_or("");
                                logging::log(
                                    "[Accounts]",
                                    &format!("账号 {display}: {message}"),
                                );
                            }
                            rewards.push(reward);
                        }
                        Err(error) => {
                            logging::verbose(
                                "[Accounts]",
                                &format!("账号 {display} 运营奖励未领取: {}", error.message),
                            );
                        }
                    }
                }
                if !rewards.is_empty() {
                    if let Some(object) = row.as_object_mut() {
                        object.insert("rewards".to_string(), Value::Array(rewards));
                    }
                }
            }
            row
        }
        other => json!({
            "id": id,
            "name": name,
            "claim": Value::Null,
            // 展示名走注册表：`other` 是 provider id，直接回显会得到
            // 「workbuddy-intl 的签到链路尚未接入」这种读不出意思的文案
            // （拆家后这条分支会先撞上国际版）。
            "error": format!(
                "{} 的签到链路尚未接入",
                crate::server::core::providers::label_of(other)
            ),
        }),
    }
}

/// CodeArts 的福利结论 → 签到结果行的 claim 形状。
///
/// 四档结论在「今天还能不能再领」这件事上分三类，映射必须与
/// [`checkin_completed_today`] / [`claim_pending`] 的口径对齐 —— 那两处是调度
/// （`auto_checkin::tick` 要不要稍后重试）、落账（要不要写 `checkinAt`）与
/// 台账（outcome 档位）共用的唯一判据：
///   · `Confirmed`（官方已确认到账）→ `success`：今天真领到了；
///   · `Already`（已领取并确认）→ `alreadyCompleted`：上游说今天已经领过 ——
///     两者都算「今天签到完成」，于是落 `checkinAt`、计入 succeeded、进签到记录；
///   · `NotEligible`（暂无可领取活动）/ `Skipped`（被本地限流闸挡住，只可能出现在
///     自动路径）→ **中性未领取**：不落账，定时链稍后重试（文案由 `claim_pending` 认）。
fn welfare_claim_of(outcome: crate::server::core::providers::codearts::welfare::Outcome) -> Value {
    use crate::server::core::providers::codearts::welfare::Outcome;
    let label = outcome.label();
    match outcome {
        Outcome::Confirmed => json!({ "success": true, "msg": label }),
        Outcome::Already => json!({ "success": false, "alreadyCompleted": true, "msg": label }),
        Outcome::NotEligible | Outcome::Skipped => json!({ "success": false, "msg": label }),
    }
}

/// 把一次签到调用翻成统一的结果行（`{id, name, claim, error}`）。
///
/// ── `log_success_msg` 为什么是一个参数而不是统一口径 ─────────
/// 小浣熊与 AutoClaw 的 claim `msg` 带**具体收益**（「今日积分 +100」
/// 「签到成功，获得 100 积分」），拼进日志才有排查价值；WorkBuddy 保持原样
/// （照抄 Node 版，不在这里做「顺手统一」—— 那会改变它既有的日志文案，
/// 而日志是用户已经在看的输出）。失败分支三家一致。
fn claim_result(
    id: String,
    name: Value,
    display: &str,
    log_success_msg: bool,
    result: Result<Value, String>,
) -> Value {
    match result {
        Ok(claim) => {
            let success = claim.get("success").and_then(Value::as_bool).unwrap_or(false);
            let msg = claim.get("msg").and_then(Value::as_str).unwrap_or("");
            if success {
                if log_success_msg && !msg.is_empty() {
                    logging::log("[Accounts]", &format!("账号 {display}: 签到成功（{msg}）"));
                } else {
                    logging::log("[Accounts]", &format!("账号 {display}: 签到成功"));
                }
            } else {
                logging::log("[Accounts]", &format!("账号 {display}: 签到未领取（{msg}）"));
            }
            json!({ "id": id, "name": name, "claim": claim, "error": Value::Null })
        }
        Err(message) => {
            // 「今天已签到」是正常状态：info 级展示，不算失败
            if message.contains("已签到") {
                logging::log("[Accounts]", &format!("账号 {id}: 今日已签到"));
            } else {
                logging::verbose("[Accounts]", &format!("账号 {id} 签到失败: {message}"));
            }
            json!({
                "id": id,
                "name": name,
                "claim": Value::Null,
                "error": message,
            })
        }
    }
}

/// 这次签到是否意味着「今天已经签过了」—— 决定要不要落 `checkinAt`。
/// `pub`：签到记录台账（`core::checkin_records`）的 outcome 判定复用它 ——
/// 「今天已完成」的口径在调度、落账与台账三处必须是同一份（判据只此一份）。
///
/// 三种情况都算，因为它们在「今天不能再领」这件事上没有区别：
///   1. `success === true`：本次真的领到了；
///   2. `alreadyCompleted === true`：上游明确告知今天已完成
///      （AutoClaw 的 `daily_signin` 会带这个字段，见 `providers::autoclaw::checkin`）；
///   3. `msg` 里含「已签到 / 已领取」：WorkBuddy 只把「今日已签到」放在文案里，
///      没有专门的码位可用，所以这里只能看文案。
///
/// 小浣熊不需要第 3 条：它的「今天已领过」是通过**账单核对**发现的 ——
/// 今天有入账记录就会算出 `granted_today > 0`，于是自然落到第 1 条。
///
/// ── 为什么不能宽到「只要没报错就算」─────────────────────────
/// 失败行（网络错误 / 凭证失效 / 5xx）与「今天已签到」是两回事：前者意味着今天
/// 可能一次都没签上，把它当作已签到去置灰按钮会白丢一天。这不是假想 ——
/// 实测见过自动签到 4 个账号全部未领取、17 秒后手动逐个重试全部成功
/// （批次撞上上游风控），所以判据必须收紧到「上游说签过了」。
pub fn checkin_completed_today(claim: &Value) -> bool {
    if claim.get("success").and_then(Value::as_bool) == Some(true) {
        return true;
    }
    if claim.get("alreadyCompleted").and_then(Value::as_bool) == Some(true) {
        return true;
    }
    let message = claim.get("msg").and_then(Value::as_str).unwrap_or("");
    message.contains("已签到") || message.contains("已领取")
}

/// 行的 `activity` 段是否携带「活跃上报成功」读数（`report.succeeded`）。
///
/// WorkBuddy 国际版每日活跃的构成：活跃上报（`/v2/report`）点亮成长中心
/// 连登；「当日活跃」计数的判定通道是网页会话（[`web_conversation_ok`]，
/// issue #277）。领取依赖上游活动开放。
pub fn activity_report_ok(row: &Value) -> bool {
    row.get("activity")
        .and_then(|activity| activity.get("report"))
        .and_then(|report| report.get("succeeded"))
        .and_then(Value::as_bool)
        .unwrap_or(false)
}

/// 行的 `activity` 段是否携带「网页会话建成」读数（`webConversation.succeeded`）。
///
/// 上游把「当日活跃」（每日 30 积分的判定）记在网页通道的 agent 会话上
/// （issue #277 的抓包结论，见 `billing::activity::create_web_conversation`）。
pub fn web_conversation_ok(row: &Value) -> bool {
    row.get("activity")
        .and_then(|activity| activity.get("webConversation"))
        .and_then(|web| web.get("succeeded"))
        .and_then(Value::as_bool)
        .unwrap_or(false)
}

/// 结果行是否代表「今天已完成」—— 落账（`checkinAt`）、调度与台账三处共用的
/// 唯一判据。
///
/// 两条来源任一成立即算完成：
///   1. **claim 说完成**（[`checkin_completed_today`]）：真领到 / 上游说已领；
///   2. **国际版每日活跃链路完成**：活跃上报或网页会话任一成功 —— 活动模块
///      下线（`active:false`，issue #277 评论里的 code 12302 状态）时领取恒为
///      「活动未开启」，但这一天的日活实际完成、积分由上游按活跃异步发放
///      （实测：全量账号收到 Bonus Pack，而领取接口仍是「活动未开启」）。
///      旧口径只看 claim，于是这批账号在签到中心永远显示「待签」、与台账
///      已记的 `already/ok` 自相矛盾。
///
/// 只保活对话成功（`pokeSucceeded`）**不算**完成：它只是「账号有调用」，
/// 上游的活跃计数不认它；失败（网络错误 / 凭证失效）也不算 —— 失败行照旧
/// 显示待签，与 [`checkin_completed_today`] 的收紧原则一致。
pub fn day_completed(row: &Value) -> bool {
    row.get("claim")
        .map(checkin_completed_today)
        .unwrap_or(false)
        || activity_report_ok(row)
        || web_conversation_ok(row)
}

/// 这条领取结果是「中性未领取」—— 不是成功、不是已签、也不是失败，而是
/// 「此刻没有可领的活动」。Qoder 国际版的活动窗口每天 10:00（UTC+8）才开，
/// 定时签到在这个窗口之前跑完时结果必然长这样；自动签到调度据此判断
/// 「今天要不要保持未落账、过段时间重试」（见 `auto_checkin::tick`）。
///
/// 判据刻意与 [`checkin_completed_today`] 相反且**只认中性文案**：把失败
/// （网络错误 / 凭证失效）也当成 pending 会让坏账号整天反复重试打上游。
pub fn claim_pending(claim: &Value) -> bool {
    if checkin_completed_today(claim) {
        return false;
    }
    // error 字段非空 = 执行出错（网络 / 凭证），那不是「等窗口」能解决的
    if claim.get("error").and_then(Value::as_str).is_some_and(|text| !text.trim().is_empty()) {
        return false;
    }
    let message = claim.get("msg").and_then(Value::as_str).unwrap_or("");
    // 两个地区的「无活动」文案都含这一句；实现改措辞时这里要跟着对齐
    //（`providers::qoder::checkin::no_claim` 与 trae 的「未领取 + 原因」不同形，
    // trae 不走这条 pending 逻辑 —— 它没有窗口概念）。
    // CodeArts 的两条（`providers::codearts::welfare::Outcome::label`）同理：
    // 「暂无可领取活动」是运营活动还没下发（再过一阵可能就有），「等待重试」是
    // 被本地那两道写闸挡住（今天还有额度、只是间隔没到）—— 两者都该让定时链
    // 稍后重试，而不是记成失败。改那边的文案时这两条也要跟着改。
    message.contains("没有可领取的签到活动")
        || message.contains("未下发每日积分活动")
        || message.contains("暂无可领取活动")
        || message.contains("等待重试")
}

/// 执行一次签到并汇总（Node 版 `runCheckin(id)`）。
///
/// `id` 为 None 时签全部符合条件的账号（定时签到走这条），范围由 `providers`
/// 决定（配置里勾选的提供商，缺省全选；**指定 id 单签时不受范围限制**）。
/// `reason` 只在批量轮次（id=None）进签到历史台账（`checkin_history`，签到中心
/// 时间线的来源）；单账号签到不进台账，只更新账号的 `checkinAt`。
/// `source` 是签到记录台账（`core::checkin_records`，schema v11）的触发来源，
/// 每个账号行落一条明细时原样带上 —— 批量与单账号共用这一处记账点。
/// **串行**：避免多账号同时打上游触发 11-128 风控。
pub async fn run_checkin(
    store: &AccountStore,
    billing: &BillingService,
    providers: &[String],
    id: Option<&str>,
    reason: &str,
    source: &str,
) -> Result<Value, CheckinError> {
    let (targets, skipped) = resolve_checkin_targets(store, providers, id)?;
    // 「这次是用户在面板上点的吗」——只有 CodeArts 用得上（它的福利是写请求，
    // 有两道本地限流闸）。单账号 single 与批量 manual 都是点击触发；
    // schedule / startup 是无人值守，必须受闸。见 `checkin_for` 的说明。
    let manual = matches!(source, "single" | "manual");
    let mut results = Vec::with_capacity(targets.len());
    for account in &targets {
        let row = checkin_for(store, billing, account, manual).await;
        // 落签到时间：手动单签与定时签到走的是**这一段**（两条链都调本函数），
        // 所以账号页的「已签到」在两种路径下都会亮起来，不需要各自记一次。
        // 写盘失败只记日志、不改签到结果 —— 上游那边积分已经领到了，
        // 因为一次落盘失败就把成功的签到报成失败是本末倒置。
        if let Some(account_id) = row.get("id").and_then(Value::as_str) {
            // 判据是 [`day_completed`]（claim 说完成，或国际版活跃链路完成）——
            // 与台账的 outcome 判定同源；判据只此一份，别在这里再写一份。
            if day_completed(&row) && !store.mark_checkin(account_id, logging::now_ms()) {
                logging::verbose(
                    "[Accounts]",
                    &format!("账号 {account_id} 的签到时间未能落盘（账号可能已被删除）"),
                );
            }
        }
        // 签到记录台账（schema v11）：每个账号行落一条明细（成败 / 错误原文 /
        // 收益文案都在结果行里）。写盘失败只记日志：台账缺一条不该让这次
        // 签到的响应报错 —— 与上面 mark_checkin 的取舍同构。provider 由账号
        // 记录带上（结果行里没有这个字段，记录页的提供商筛选列要用）。
        crate::server::core::checkin_records::record_row(
            &row,
            account.get("provider").and_then(Value::as_str).unwrap_or(""),
            source,
            reason,
        );
        results.push(row);
    }
    // 「真实领取」与「今日已领取」都表示本日成功领到分，计入 succeeded；
    // 活跃链路（保活对话 / 活跃上报 / 网页会话）单独统计在 `active` ——
    // 它不产生「领取」，不并入 succeeded，免得把两类事混成一个数。
    // 注意 succeeded 只是这行日志的计数：落 `checkinAt` 的判据是
    // [`day_completed`]（活跃链路完成同样落账），两者刻意不同 —— 前者计量
    // 「真领到的分」，后者回答「今天是否已完成」。
    let succeeded = results
        .iter()
        .filter(|item| {
            item.get("claim")
                .map(checkin_completed_today)
                .unwrap_or(false)
        })
        .count();
    let active = results
        .iter()
        .filter(|item| {
            item.get("activity")
                .and_then(|activity| activity.get("pokeSucceeded"))
                .and_then(Value::as_bool)
                .unwrap_or(false)
                // 活跃上报（/v2/report，点亮国际版连登的那条通道）与网页会话
                // （issue #277：「当日活跃」计数的判定通道）成功同样算「完成活跃」。
                || activity_report_ok(item)
                || web_conversation_ok(item)
        })
        .count();
    if skipped > 0 {
        logging::log(
            "[Accounts]",
            &format!("已跳过 {skipped} 个账号（不支持签到/活跃任务或不在签到范围内）"),
        );
    }
    logging::log(
        "[Accounts]",
        &format!(
            "签到完成: {succeeded}/{} 个账号成功领取，{active} 个账号完成活跃保活",
            results.len()
        ),
    );
    // 批量轮次进台账（签到中心时间线）。写盘失败只记日志：上游那边积分已经
    // 领到，台账缺一条不该让这次签到的响应报错。
    if id.is_none() {
        crate::server::core::checkin_history::record(
            &json!({
                "succeeded": succeeded,
                "active": active,
                "total": results.len(),
                "skipped": skipped,
                "results": results,
            }),
            reason,
        );
    }
    // ── 连登管家：补签 → 档位兑换 → 抽奖（挂签到末尾，与参考项目同款）──
    //
    // 为什么挂在这里而不是独立排程：三件事的判据都依赖「今天签到了没有」
    // （连登天数当天 +1 之后才可能解锁新档位），紧跟签到跑最准；而签到是
    // 手动与定时共用的唯一入口（`run_checkin` 是两条链的共同执行体），
    // 挂这里天然覆盖两条路径，不必各写一遍。
    //
    // ── 为什么是**后台任务**而不是 await ────────────────────────
    // 三件事每个账号要 4~6 个上游请求（热力图 / 连登状态 / 兑换 / 抽奖余额 /
    // 逐次抽奖），加上账号间 800ms 错峰，十几个账号就是几十秒到几分钟 ——
    // 而管理 API 有 60 秒单请求超时（`gateway::REQUEST_TIMEOUT_MS`）。同步
    // await 会让前端「立即全部签到」超时报错，而后端其实已经跑完，用户以为
    // 失败了会再点一次。所以这里**只起任务不等待**：签到结果立刻返回，
    // 连登管家的收益异步进日志与账号余额。
    //
    // 失败**不影响**签到结果：三件事在上游都是幂等的附加收益，且都只服务
    // 国内版个人账号（门控在 `run_for_accounts` 里）。任何一步出错只进日志，
    // 绝不把一次成功的签到报成失败 —— 与上面 mark_checkin / record_row 的
    // 取舍同构。
    //
    // 只在**批量轮次**跑（`id.is_none()`）：单账号手动签到是「我只想签这一个」，
    // 顺手替它兑换抽奖会让用户以为点错了按钮；批量（定时 / 手动全量）才是
    // 「维护一遍所有账号」的意图。
    if id.is_none() {
        spawn_streak_bonus(store.clone(), targets.clone());
    }
    Ok(json!({
        "results": results,
        "succeeded": succeeded,
        "active": active,
        "total": results.len(),
        "skipped": skipped,
    }))
}

/// 连登管家：后台跑「补签 → 档位兑换 → 抽奖」，不阻塞签到响应。
///
/// 抽成独立函数的原因有三条：
///   1. **不阻塞**：见 `run_checkin` 里那段「为什么是后台任务」；
///   2. **隔离失败**：里面任何错误都只进日志，不会冒泡到签到结果；
///   3. **串行闸**：同一时刻只允许一轮在跑（手动连点签到不会叠出两轮
///      重复兑换 / 抽奖 —— 上游幂等，但重复打请求本身是浪费且招风控）。
fn spawn_streak_bonus(store: AccountStore, targets: Vec<Value>) {
    /// 进程内串行闸：`swap(true)` 抢到才跑，跑完复位。
    static RUNNING: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
    if RUNNING.swap(true, std::sync::atomic::Ordering::SeqCst) {
        logging::verbose("[Streak]", "上一轮连登管家仍在执行，本次跳过");
        return;
    }
    crate::spawn_task(async move {
        let reports = crate::server::core::providers::workbuddy::growth::streak::run_for_accounts(
            &store, &targets,
        )
        .await;
        let done: usize = reports.iter().map(|report| report.done).sum();
        let failed: usize = reports.iter().map(|report| report.failed).sum();
        if done > 0 || failed > 0 {
            logging::log(
                "[Streak]",
                &format!(
                    "连登管家完成：{done} 项动作{}",
                    if failed > 0 { format!("，{failed} 项失败") } else { String::new() }
                ),
            );
        }
        RUNNING.store(false, std::sync::atomic::Ordering::SeqCst);
    });
}

#[cfg(test)]
mod tests {
    //! 签到「今天已签」判据的边界。
    //!
    //! ── 为什么这里要有一条**闭环**测试 ──────────────────────────
    //! 上游（`billing::call_billing`）与下游（本模块的 `checkin_completed_today`）
    //! 各判一次「今天已领过」，两处都靠**文案**：前者决定要不要把 HTTP 400 放行成
    //! `Ok`，后者决定要不要落 `checkinAt`。两处必须同源 —— 只放宽一处，就会出现
    //! 「放行了却仍判不出已完成」（面板不亮）或「判得出但先被丢成 Err」（`claim`
    //! 为 null）这两种半截修复。`closed_loop_tolerated_400_reaches_completed` 把
    //! 这条链整条钉住，是本次修复（上游 issue #137）唯一的端到端回归保护。
    use super::checkin_completed_today;
    use crate::server::core::billing::request::BillingCall;
    use crate::server::core::billing::{is_duplicate_claim, normalize_daily_claim, BillingService};
    use serde_json::{json, Value};

    /// 上游真实的 400 文案（WorkBuddy 国内版当日已签到时的原话）。
    const REAL_DUPLICATE: &str = "今天已签到，请明天再来";

    // ── 下游判据本身 ────────────────────────────────────────────

    #[test]
    fn success_and_already_completed_are_done() {
        // 第 1 条：本次真的领到了
        assert!(checkin_completed_today(&json!({"success": true, "code": 0})));
        // 第 2 条：上游明确告知（AutoClaw 的 daily_signin 带这个字段）
        assert!(checkin_completed_today(&json!({"success": false, "alreadyCompleted": true})));
    }

    #[test]
    fn message_wording_marks_today_done() {
        // 第 3 条：WorkBuddy 只把「今日已签到」放在文案里，没有码位可用
        assert!(checkin_completed_today(&json!({"success": false, "msg": REAL_DUPLICATE})));
        assert!(checkin_completed_today(&json!({"success": false, "msg": "该奖励已领取"})));
    }

    #[test]
    fn real_failures_are_never_mistaken_for_done() {
        // 核心不变量（见本文件上方 `checkin_completed_today` 的注释）：失败行与
        // 「今天已签到」是两回事，把前者当作已签到会白丢一天积分 —— 实测见过
        // 批次撞风控 4 个账号全部未领取。这几条必须全部为 false。
        for claim in [
            json!({"success": false, "code": -1, "msg": "计费接口请求失败: 连接上游超时"}),
            json!({"success": false, "code": -1, "msg": "登录态已过期或被拒绝，无法调用计费接口"}),
            json!({"success": false, "code": -1, "msg": ""}),
            // 键缺失：`claim` 为 null 时上游路径根本没走到判据，这里模拟 msg 缺失
            json!({"success": false, "code": 40001}),
        ] {
            assert!(!checkin_completed_today(&claim), "不该被判成已完成: {claim}");
        }
    }

    // ── 闭环：上游放行 → 下游判得出 ─────────────────────────────

    #[test]
    fn closed_loop_tolerated_400_reaches_completed() {
        // 模拟 `call_billing` 在 `tolerate_duplicate_claim: true` 时对 400 的放行：
        // 返回 `Ok(BillingCall { code, msg, data: Null, .. })`，msg 是上游文案。
        // `code` 取 null —— 上游 400 响应体里没有顶层 `code` 时就是这个形态。
        let tolerated = BillingCall {
            code: None,
            msg: Some(REAL_DUPLICATE.to_string()),
            request_id: None,
            data: Value::Null,
            raw: Some(json!({ "msg": REAL_DUPLICATE })),
        };

        // 1) 上游确实会放行这一条（判据命中）
        assert!(is_duplicate_claim(400, REAL_DUPLICATE));

        // 2) 放行后的归一化产出：失败形状，但 msg 保留上游文案
        let claim = normalize_daily_claim(tolerated);
        assert_eq!(claim.get("success").and_then(Value::as_bool), Some(false));
        assert_eq!(claim.get("msg").and_then(Value::as_str), Some(REAL_DUPLICATE));

        // 3) 下游据此判出「今天已完成」→ `mark_checkin` 会被调用、面板标识点亮。
        //    这一跳就是 #137 里断掉的那一环：原代码在 1) 之前就 Err 了，claim 为
        //    null，于是这里恒为 false，`checkinAt` 永远写不进去。
        assert!(
            checkin_completed_today(&claim),
            "放行了却判不出已完成 —— 上游与下游的文案判据已经脱钩"
        );
    }

    #[test]
    fn closed_loop_non_duplicate_400_stays_failed() {
        // 反向：同为 400，文案与「重复领取」无关时上游**不**放行（仍 Err），
        // 因此不会有 claim 走到下游。这里直接断言判据不命中，钉住「不能过度放宽」。
        for detail in ["参数错误", "请求内容不是有效 JSON", "活动已结束"] {
            assert!(!is_duplicate_claim(400, detail), "detail={detail:?} 不该被放行");
        }
    }

    // ── HTTP 接线：真正驱动 `call_billing` 的修复分支 ────────────
    //
    // ⚠️ 上面那些测试**都不足以保护真正的修复点**。`closed_loop_*` 是手工构造
    // `BillingCall` 再调 `normalize_daily_claim`，绕过了 `call_billing` —— 把
    // `mod.rs` 里 `if options.tolerate_duplicate_claim && is_duplicate_claim(...)`
    // 整段删掉或改成 `if false`，它们**依然全绿**（`is_duplicate_claim` 自己的
    // 测试也照样过，因为那函数还在）。下面三条起真的 HTTP 服务，让 400 从 socket
    // 上走一遍，把「修复分支本身」钉住 —— 这是 #137 的回归保护里唯一不可绕过的
    // 一层。

    /// 起一个只回固定响应的 mock 上游（照抄 `upstream::provider_loop::tests`
    /// 的手写 axum 约定，项目既有风格，不引入 wiremock）。
    /// 返回 (base_url, 命中计数, 任务句柄)；句柄由调用方持有到用例结束。
    async fn mock_billing(
        status: u16,
        body: &'static str,
    ) -> (
        String,
        std::sync::Arc<std::sync::atomic::AtomicUsize>,
        tokio::task::JoinHandle<()>,
    ) {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::sync::Arc;
        let hits = Arc::new(AtomicUsize::new(0));
        let count = hits.clone();
        let app = axum::Router::new().route(
            "/v2/billing/meter/daily-checkin",
            axum::routing::post(move || {
                count.fetch_add(1, Ordering::SeqCst);
                async move {
                    (
                        axum::http::StatusCode::from_u16(status).unwrap(),
                        [(axum::http::header::CONTENT_TYPE, "application/json")],
                        body,
                    )
                }
            }),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let base = format!("http://{}", listener.local_addr().unwrap());
        let task = tokio::spawn(async move { axum::serve(listener, app).await.unwrap() });
        (base, hits, task)
    }

    /// 指向 mock 的国内版 session —— `call_billing` 从这里取 endpoint 与请求头。
    /// `edition: "cn"` 是关键：为 `intl` 会走国际版活跃任务链，根本不打这个端点。
    fn cn_session(base: &str) -> Value {
        json!({
            "endpoint": base,
            "edition": "cn",
            "auth": { "accessToken": "test-token" },
            "account": { "uid": "u1" },
        })
    }

    /// 建一个可用的 `BillingService`（空账号库即可 —— session 由调用方直接给）。
    fn billing_service(label: &str) -> (BillingService, crate::server::db::test_temp::TempDb) {
        use crate::server::core::account_store::AccountStore;
        let (db, guard) = crate::server::db::test_temp::TempDb::open(label);
        let store = AccountStore::with_db(Some(db));
        (
            BillingService::new(crate::server::core::auth::AuthService::for_store(store)),
            guard,
        )
    }

    #[tokio::test]
    async fn tolerated_400_from_real_http_reaches_completed() {
        let (billing, _guard) = billing_service("billing-checkin-400");
        let (base, hits, _task) = mock_billing(400, r#"{"msg":"今天已签到，请明天再来"}"#).await;

        let claim = billing
            .claim_daily_checkin(Some(&cn_session(&base)))
            .await
            .expect("400 +「今天已签到」应被容错放行，而不是 Err");

        assert_eq!(
            hits.load(std::sync::atomic::Ordering::SeqCst),
            1,
            "只该打一发上游（重复领取不做重试）"
        );
        assert_eq!(claim.get("success").and_then(Value::as_bool), Some(false));
        assert_eq!(claim.get("msg").and_then(Value::as_str), Some(REAL_DUPLICATE));
        // 端到端闭环：这一跳就是 #137 断掉的地方（原代码在上一行就 Err 了，
        // claim 为 null，于是这里恒为 false，checkinAt 永远写不进去）。
        assert!(checkin_completed_today(&claim), "#137：放行后仍判不出已完成");
    }

    #[tokio::test]
    async fn non_duplicate_400_from_real_http_still_errors() {
        let (billing, _guard) = billing_service("billing-checkin-400-other");
        let (base, _hits, _task) = mock_billing(400, r#"{"msg":"参数错误"}"#).await;

        let error = billing
            .claim_daily_checkin(Some(&cn_session(&base)))
            .await
            .expect_err("文案与重复领取无关的 400 必须照旧报错");
        assert!(error.message.contains("400"), "message={}", error.message);
    }

    #[tokio::test]
    async fn server_error_from_real_http_still_errors() {
        let (billing, _guard) = billing_service("billing-checkin-500");
        // 500 是**真故障**：即便文案恰好含「已签到」也不能放行，否则一次没签上的
        // 日子会被记成已签（`checkin.rs` 注释里实测过的批次撞风控场景）。
        let (base, _hits, _task) = mock_billing(500, r#"{"msg":"今天已签到，请明天再来"}"#).await;

        billing
            .claim_daily_checkin(Some(&cn_session(&base)))
            .await
            .expect_err("500 不该被容错放行");
    }
}
